import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class BarControl implements KeyListener {
	private int x, y;
	private int pushedKey;
	private int direction;
	private boolean pushedSpace;
	private boolean gameStart = false;

	public void keyPressed(KeyEvent e) {
			pushedKey = e.getKeyCode();
			if(gameStart == false && pushedKey == KeyEvent.VK_SPACE)
			{
				gameStart = true;
			}
			if(pushedKey == KeyEvent.VK_LEFT || pushedKey == KeyEvent.VK_A)
			{
				direction=1;
			}
			else if(pushedKey == KeyEvent.VK_RIGHT || pushedKey == KeyEvent.VK_D)
			{
				direction=2;
			}
			else
				direction=0;
	}

	public void keyReleased(KeyEvent e) {
		direction=0;
	}

	public int getDirection()	{
		return direction;
	}
	//������� �ʴ� �⺻ �޼ҵ�
	public void keyTyped(KeyEvent e) {

	}
	
	public boolean get_gameStart() {
		return gameStart;
	}
	public void set_gameStart(boolean checkStart) {
		gameStart = checkStart;
	}
}
