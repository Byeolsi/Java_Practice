package AI;

public class ParentInfo
{
	int exp;
	int x,y;
	int state;
	/*Store the information of parent tile(depth 1)*/
	public ParentInfo(int exp,int x,int y,int state)
	{
		this.exp = exp;
		this.x = x;
		this.y = y;
		this.state = state;
	}
}
