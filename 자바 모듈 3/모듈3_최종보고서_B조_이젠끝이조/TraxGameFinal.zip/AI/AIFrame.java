package AI;

import GUI.trax_frame;

/*
 * It's the virtual frame for AI
 * */
public class AIFrame
{	
	
	public static int n = 128;
	public static boolean f_click = false;
	public static boolean b_win = false;
	public static boolean w_win = false;
	public static AIButton[] btns = new AIButton[n*n];

	//Button initialization
	public static void initBtn()
	{
		for(int i = 0;i<n*n;i++) {
			btns[i] = new AIButton(i%n,i/n);
		}
	}
	
	//Button synchronization. Using trax_frame
	public static void synchronization()
	{
		f_click = trax_frame.f_click;
		for(int i = 0;i<n*n;i++) {
			btns[i].state = trax_frame.btns[i].state;
			btns[i].click_en = trax_frame.btns[i].click_en;
			btns[i].click_ch = trax_frame.btns[i].click_ch;
		}
	}

}