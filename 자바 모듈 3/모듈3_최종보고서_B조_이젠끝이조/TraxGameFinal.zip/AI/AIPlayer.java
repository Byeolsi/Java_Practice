package AI;

import java.lang.Math;
import java.util.ArrayList;

import GUI.tileButton;
import GUI.trax_frame;
public class AIPlayer
{
	public static boolean turn = false;// true : AI is white  false : AI is black
	private int n = AIFrame.n;//n*n is the number of the tileButton.
	private int randState;//It's for AI to choose when AI is the first turn.
	public static ArrayList<Expectation> exp = new ArrayList<Expectation>();//Store the expectation.
	public static ArrayList<Expectation> exp2 = new ArrayList<Expectation>();//Store the previous expectation.
	private ArrayList<ArrayList<Integer>> whiteLineState = new ArrayList<ArrayList<Integer>>();
	//Store the index of tiles who are connected each other with white line. It'll be using at goBack(), saveFrameState()
	private ArrayList<ArrayList<Integer>> blackLineState = new ArrayList<ArrayList<Integer>>();
	//Store the index of tiles who are connected each other with black line. It'll be using at goBack(), saveFrameState()
	private ArrayList<ParentInfo> parentState = new ArrayList<ParentInfo>();
	//store the parent tile of depth 3.
	private boolean f_click;// true : It's first click
	ArrayList<FrameState> frameState = new ArrayList<FrameState>();//Store the state of frame
	private boolean flag = false;// true : stop the method "doRightClick".
	public AIPlayer() {}
	public void simulate()
	{
		randState = (int)(Math.random()*100+1);
		//synchronization
		AIFrame.initBtn();
		AIFrame.synchronization();
		AIButton.check.synchronization();
		//clear the arraylist
		exp.clear();
		parentState.clear();
		
		//first trial
		firstTrial();
		
		//store the expectation of depth 1
		exp2.clear();
		exp2.addAll((ArrayList<Expectation>)exp.clone());
		
		//If there is move to win or lose, do attack or defend
		sortExp(exp);
		if((exp.get(0).exp == 100000) || (exp.get(exp.size()-1).exp == -100000)) {
			flag = true;
			atkOrDef();
			return;
		}
		//Clear exp and do second moves(opponent's move) 
		exp.clear();
		saveFrameState();
		changeTeam();
		for(int i = 0;i<exp2.size();i++) {
			
			AIFrame.btns[n*exp2.get(i).y+exp2.get(i).x].state = exp2.get(i).state; 
			AIButton.rightClick(exp2.get(i).x, exp2.get(i).y);
			tryRightClick();
			
			//Check if there is opponent's win case
			for(int k = 0;k<exp.size();k++) {
				if(exp.get(k).exp == 100000) {
					exp2.get(i).exp = -192;
				}
			}
			
			//Find the biggest expectation(opponent)
			Expectation big = exp.get(0);
			int bigIndex = 0;
			for(int j = 0;j<exp.size();j++) {
				if(big.exp < exp.get(j).exp) {
					big = exp.get(j);
					bigIndex = j;
				}
			}
			//If opponent did best option.
			AIFrame.btns[n*exp.get(bigIndex).y+exp.get(bigIndex).x].state = exp.get(bigIndex).state; 
			AIButton.rightClick(exp.get(bigIndex).x, exp.get(bigIndex).y);
			//Clear exp, do AI's moves, and store the exp
			exp.clear();
			changeTeam();
			secondTrial();
			changeTeam();
			big = exp.get(0);
			int newBigIndex = 0;
			//Find biggest one.
			for(int j = 0;j<exp.size();j++) {
				if(big.exp < exp.get(j).exp) {
					big = exp.get(j);
					newBigIndex = j;
				}
			}
			//Store the parent's state and index(depth 1)
			parentState.add(new ParentInfo(exp.get(newBigIndex).exp,exp2.get(i).x,exp2.get(i).y,exp2.get(i).state));
			goBack();
		}
		//Change AI's turn because AI's turn was changed in for loop.
		changeTeam();
	}
	
	//Sorting the expectation array
	private void sortExp(ArrayList<Expectation> exp)
	{
		for(int i = 0;i<exp.size();i++) {
			for(int j = i;j<exp.size();j++) {
				if(exp.get(i).exp < exp.get(j).exp) {
					Expectation tmp = exp.get(i);
					exp.set(i, exp.get(j));
					exp.set(j, tmp);
				}
			}
		}
	}
	
	//First trial of AI(depth 1)
	private void firstTrial()
	{
		this.tryRightClick();
	}
	
	//Second trial of AI(depth3)
	private void secondTrial()
	{
		this.tryRightClick();
	}
	
	public void tryRightClick() 
	{
		saveFrameState();
		if(turn == true) {//AI is white
			if(AIFrame.f_click) {//If it's first click
				if(randState <= 50) {
					AIFrame.btns[n*63+63].state = 3;
					AIButton.rightClick(63, 63);
					goBack();
					return;
				}else {
					AIFrame.btns[n*63+63].state = 5;
					AIButton.rightClick(63, 63);
					goBack();
					return;
				}
			}else {//If it's not a first trial.
				//Find enabled button and store possible state in arrayList
				for(int i = 0;i<AIFrame.btns.length;i++) {
					if(AIFrame.btns[i].click_en == true && AIFrame.btns[i].click_ch == false) {
						ArrayList<Integer> possibleState = AIFrame.btns[i].AroundRoop(i%n, i/n);
						//Do each state.
						for(int j = 0;j<possibleState.size();j++) {
							AIFrame.btns[i].state = possibleState.get(j);
							AIButton.rightClick(i%n, i/n);
							goBack();
						}
					}
				}
			}
		}else {//AI is black
			//Find enabled button and store possible state in arrayList
			for(int i = 0;i<AIFrame.btns.length;i++) {
				if(AIFrame.btns[i].click_en == true && AIFrame.btns[i].click_ch == false) {
					ArrayList<Integer> possibleState = AIFrame.btns[i].AroundRoop(i%n, i/n);
					//Do each state.
					for(int j = 0;j<possibleState.size();j++) {
						AIFrame.btns[i].state = possibleState.get(j);
						AIButton.rightClick(i%n, i/n);
						goBack();
					}
				}
			}
		}
	}
	
	private void atkOrDef()
	{
		//If AI should win.
		if(exp.get(0).exp == 100000) {
			trax_frame.btns[n*exp.get(0).y + exp.get(0).x].state = exp.get(0).state;
			tileButton.rightClick(exp.get(0).x,exp.get(0).y);
			trax_frame.printCoordinates(exp.get(0).x, exp.get(0).y, trax_frame.btns[n*exp.get(0).y + exp.get(0).x].state, true);
		}else {
			//If AI should lose.
			ArrayList<Integer> around = tileButton.AroundRoop(exp.get(exp.size()-1).x, exp.get(exp.size()-1).y);
			//Get possible state and remove worst move(state)
			for(int i = 0;i<around.size();i++) {
				if(around.get(i) == exp.get(exp.size()-1).state) {
					around.remove(i);
				}
			}
			//Do the right click(defend)
			trax_frame.btns[n*exp.get(exp.size()-1).y + exp.get(exp.size()-1).x].state = around.get(0);
			tileButton.rightClick(exp.get(exp.size()-1).x,exp.get(exp.size()-1).y);
			trax_frame.printCoordinates(exp.get(exp.size()-1).x, exp.get(exp.size()-1).y, trax_frame.btns[n*exp.get(exp.size()-1).y + exp.get(exp.size()-1).x].state, true);
			
			//Change the turn(AI's turn ended.
			if(GUI.tileButton.turn) {
				GUI.tileButton.turn = false;
			}else {
				GUI.tileButton.turn = true;
			}
			//Show whose turn.
			if(GUI.tileButton.turn) {
				GUI.trax_frame.turn.setText("White turn");
			}else {
				GUI.trax_frame.turn.setText("Black turn");
			}
		}
	}
	//It's the method for AI to do.
	public void doRightClick()
	{	
		//get the turn(white or black)
		turn = GUI.tileButton.turn;
		//simulate and find the best one
		this.simulate();
		
		//If there is win case or lose case, end this method. Because there is "atkOrDef" method for this case.
		if(flag) {
			flag = false;
			return;
		}
		//Find the best case.
		ParentInfo big = parentState.get(0);
		for(int i = 0;i<parentState.size();i++) {
			if(big.exp < parentState.get(i).exp) {
				big = parentState.get(i);
			}
		}
		//Do the right click
		trax_frame.btns[n*big.y + big.x].state = big.state;
		tileButton.rightClick(big.x,big.y);
		trax_frame.printCoordinates(big.x, big.y, big.state, true);
		
		//Change the turn(AI's turn ended.
		if(GUI.tileButton.turn) {
			GUI.tileButton.turn = false;
		}else {
			GUI.tileButton.turn = true;
		}
		//Show whose turn.
		if(GUI.tileButton.turn) {
			GUI.trax_frame.turn.setText("White turn");
		}else {
			GUI.trax_frame.turn.setText("Black turn");
		}
	}
	//Store the state of frame.
	private void saveFrameState()
	{			
		whiteLineState.clear();
		blackLineState.clear();
		for(int i = 0;i<AIVictoryLine.whiteLine.size();i++) {
			whiteLineState.add((ArrayList)AIVictoryLine.whiteLine.get(i).clone());
		   }
		for(int i = 0;i<AIVictoryLine.blackLine.size();i++) {
		    blackLineState.add((ArrayList)AIVictoryLine.blackLine.get(i).clone());
		}
		
		f_click = AIFrame.f_click;
		//Store button's info.
		frameState.clear();
		for(int i = 0;i<AIFrame.btns.length;i++) {
			frameState.add(new FrameState(i, AIFrame.btns[i].state,AIFrame.btns[i].click_en,AIFrame.btns[i].click_ch));
		}
	}
	
	//bring back the frame state
	private void goBack()
	{
		AIVictoryLine.whiteLine.clear();
		AIVictoryLine.blackLine.clear();
		
		for(int i = 0;i<whiteLineState.size();i++) {
			AIVictoryLine.whiteLine.add((ArrayList)whiteLineState.get(i).clone());
		   }
		for(int i = 0;i<blackLineState.size();i++) {
		    AIVictoryLine.blackLine.add((ArrayList)blackLineState.get(i).clone());
		}
		AIFrame.f_click = f_click;
		for(int i = 0;i<frameState.size();i++) {
			AIFrame.btns[frameState.get(i).index].state = frameState.get(i).state;
			AIFrame.btns[frameState.get(i).index].click_en = frameState.get(i).click_en;
			AIFrame.btns[frameState.get(i).index].click_ch = frameState.get(i).click_ch;
		}
	}

	//Change turn.
	private void changeTeam() 
	{	
		if(turn) {
			turn = false;
		}else {
			turn = true;
		}
	}

}
