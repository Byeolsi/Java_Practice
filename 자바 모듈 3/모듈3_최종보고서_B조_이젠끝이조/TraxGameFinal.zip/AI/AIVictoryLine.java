package AI;

import java.util.ArrayList;

public class AIVictoryLine extends AILineCheck
{
	  public AIVictoryLine() {}
	  
	  public void victory_check(int index)
	  {
	      int lb = blackLine.size();
	      int lw = whiteLine.size();
	      boolean blWin = false,Whwin = false;
	      
	      //Check black line
	      for(int i=0;i<lb;i++) {
	         int l = blackLine.get(i).size();
	         //no loop or size.
	         if(l<3)
	            continue;
	         //loop, black win
	         if(count(blackLine,index) == 2) {
	            AIFrame.b_win = true;
	            Whwin = false;
	            blWin = true;
	            break;
	         }
	         //line, black win.
	         if(line(blackLine.get(i).get(0), blackLine.get(i).get(l-1),1)) {
	            AIFrame.b_win = true;
	            Whwin = false;
	            blWin = true;
	            break;
	         }
	      }
	      //Check white line
	      for(int i=0;i<lw;i++) {
	         int l = whiteLine.get(i).size();
	         //no loop or line
	         if(l<3)
	            continue;
	         //loop, white win
	         if(count(whiteLine,index)==2) {
	        	AIFrame.w_win = true;
	        	Whwin = true;
	        	blWin = false;
	        	break;
	         }
	         //line, white win
	         if(line(whiteLine.get(i).get(0), whiteLine.get(i).get(l-1), 2)) {
	        	AIFrame.w_win = true;
	        	Whwin = true;
	        	blWin = false;
	        	break;
	         }
	      }
	      //AI is black(save expectation by cases)
	      if(!AIPlayer.turn && AIFrame.btns[index].state != 0) {
	    	  int state = AIFrame.btns[index].getState();
	    	  
	    	  if(Whwin && !blWin) {//white win(AI lose)
	    		  AIPlayer.exp.add(new Expectation(state,index%n,index/n,-100000));
	    	  }else if(!Whwin && blWin) {//black win(AI win)
	    		  AIPlayer.exp.add(new Expectation(state,index%n,index/n,100000));
	    	  }else {//no winner yet
	    		  int[] gap = getGap(blackLine,index);
	    		  if(gap[0] <= gap[1]) {//width <= height
	    			  if(8-gap[1] >= gap[0]+gap[1]) {//loop better
	    				  if(gap[0]+gap[1] <= 3) {//at most three more tiles to loop
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,8));
	    				  }else if(gap[0]+gap[1] > 3 && gap[0]+gap[1] <= 5) {//4 ~ 5 more tiles to loop
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,5));
	    				  }else {
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,2));
	    				  }
	    			  }else {//line better
	    				  if(8-gap[1] <= 3) {//at most three more tiles to loop
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,7));
	    				  }else if(8-gap[1] > 3 && 8-gap[1] <= 5) {//4 ~ 5 more tiles to loop
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,4));
	    				  }else {
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,1));
	    				  }
	    			  }
	    		  }else {//width > height
	    			  if(8-gap[0] >= gap[0]+gap[1]){//loop better
	    				  if(gap[0]+gap[1] <= 3) {//at most three more tiles to loop
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,8));
	    				  }else if(gap[0]+gap[1] > 3 && gap[0]+gap[1] <= 5) {//4 ~ 5 more tiles to loop
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,5));
	    				  }else {
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,2));
	    				  }
	    			  }else {
	    				  //line better
	    				  if(8-gap[0] <= 3) {
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,7));
	    				  }else if(8-gap[0] > 3 && 8-gap[0] <= 5) {
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,4));
	    				  }else {
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,1));
	    				  }
	    			  }
	    		  }
	    	  }
	      }else {//AI is white
	    	  int state = AIFrame.btns[index].getState();
	    	  if(Whwin && !blWin) {//white win(AI win)
	    		  AIPlayer.exp.add(new Expectation(state,index%n,index/n,100000));
	    	  }else if(!Whwin && blWin){//black win(AI lose)
	    		  AIPlayer.exp.add(new Expectation(state,index%n,index/n,-100000));
	    	  }else {//no winner yet
	    		  int[] gap = getGap(whiteLine,index);
	    		  if(gap[0] <= gap[1]) {//width <= height
	    			  if(8-gap[1] >= gap[0]+gap[1]) {//loop better
	    				  if(gap[0]+gap[1] <= 3) {//at most three more tiles to loop
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,8));
	    				  }else if(gap[0]+gap[1] > 3 && gap[0]+gap[1] <= 5) {//4 ~ 5 more tiles to loop
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,5));
	    				  }else {
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,2));
	    				  }
	    			  }else {//line better
	    				  if(8-gap[1] <= 3) {//at most 3 more tiles to line
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,7));
	    				  }else if(8-gap[1] > 3 && 8-gap[1] <= 5) {//4 ~ 5 more tiles to line
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,4));
	    				  }else {
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,1));
	    				  }
	    			  }
	    		  }else {//width >= height
	    			  if(8-gap[0] >= gap[0]+gap[1]){//loop better
	    				  if(gap[0]+gap[1] <= 3) {//at most 3 more tiles to loop
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,8));
	    				  }else if(gap[0]+gap[1] > 3 && gap[0]+gap[1] <= 5) {//4 ~ 5 more tiles to loop
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,5));
	    				  }else {
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,2));
	    				  }
	    			  }else {//line better
	    				  if(8-gap[0] <= 3) {//at most 3 more tiles to line
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,7));
	    				  }else if(8-gap[0] > 3 && 8-gap[0] <= 5) {//4 ~ 5 more tiles to line
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,4));
	    				  }else {
	    					  AIPlayer.exp.add(new Expectation(state,index%n,index/n,1));
	    				  }
	    			  }
	    		  }
	    	  }
	      }
	      
	  }

	  //return the gap of first, last tiles.
	  int[] getGap(ArrayList<ArrayList<Integer>> list, int item) 
	  {
		  int line = -1;
		  int n = AIFrame.n;
		  //Find the index which contains(item)
		  for(int i = 0; i < list.size(); i++){
			  for(int j = 0;j<list.get(i).size();j++) {
				  if(item == list.get(i).get(j)){
		               line = i;
		               break;
		            }
			  }
		  }
		  int x,y;
		  int lastX,lastY;
		  int[] gap = new int[2];
		  
		  x = list.get(line).get(0)%n;
		  y = list.get(line).get(0)/n;
		  
		  lastX = list.get(line).get(list.get(line).size()-1)%n;
		  lastY = list.get(line).get(list.get(line).size()-1)/n;
		  
		  gap[0] = x-lastX;
		  gap[1] = y-lastY;
		  //no negative
		  if(gap[0]<0)
			  gap[0] = -gap[0];
		  if(gap[1]<0)
			  gap[1] = -gap[1];
		  return gap;
	  }
	  
	  //count how many items in it. If it has two item in one line that means loop
	  int count(ArrayList<ArrayList<Integer>> list, int item)
	  {
	      int cnt=0;
	      for(int i = 0; i < list.size(); i++){
	         for(int j = 0; j < list.get(i).size(); j++){
	            if(item == list.get(i).get(j)){
	               cnt++;
	            }
	         }
	      }
	      return cnt;
	  }
	  
	  /*
	   * Check line-win condition
	   * color 1: black 2: white
	   * */
	  boolean line(int i1, int i2, int color)
	  {
	      int x1 = i1%n, x2 = i2%n;
	      int y1 = i1/n, y2 = i2/n;
	      int state1 = AIFrame.btns[i1].getState();
	      int state2 = AIFrame.btns[i2].getState();
	      int temp;
	      
	      //If width >= 8, change state each other.
	      if(getGap(x1,x2)>=8) {
	         //classify which is right state.
	    	 if(x1 < x2) {
	            temp = state1;
	            state1 = state2;
	            state2 = temp;
	         }
	         
	         switch(color) {
	         
	         case 1 :{//black
	            if(state2==2||state2==3||state2==6)
	               break;
	            else {
	               if(state1==1||state1==4||state1==6)
	                  break;
	               else
	                  return true;
	            }
	         }
	         case 2 :{//white
	            if(state2==1||state2==4||state2==5)
	               break;
	            else {
	               if(state1==2||state1==3||state1==5)
	                  break;
	               else
	                  return true;
	            }
	         }
	         }
	      }
	      
	      state1 = AIFrame.btns[i1].getState();
	      state2 = AIFrame.btns[i2].getState();
	      
	      if(getGap(y1,y2)>=8) {
	    	 //classify which is upper state.
	         if(y1<y2) {
	            temp = state1;
	            state1 = state2;
	            state2 = temp;
	         }
	         
	         switch(color) {
	         case 1 :{//black
	            if(state2==3||state2==4||state2==5)
	               break;
	            else {
	               if(state1==1||state1==2||state1==5)
	                  break;
	               else
	                  return true;
	            }
	         }
	         case 2 :{//white
	            if(state2==1||state2==2||state2==6)
	               break;
	            else {
	               if(state1==3||state1==4||state1==6)
	                  break;
	               else
	                  return true;
	            }
	         }
	         }
	         
	      }
	      return false;
	  }
}
