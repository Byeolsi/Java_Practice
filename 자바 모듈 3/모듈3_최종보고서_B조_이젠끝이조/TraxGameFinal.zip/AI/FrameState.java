package AI;

public class FrameState
{
	int state;
	int index;
	boolean click_en;
	boolean click_ch;
	/*
	 * Store the state of the frame.
	 * */
	//constructor
	public FrameState(int index,int state,boolean click_en,boolean click_ch) 
	{
		this.index = index;
		this.state = state;
		this.click_en = click_en;
		this.click_ch = click_ch;
	}
}
