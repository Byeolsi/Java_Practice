package AI;

public class Expectation
{
	public int state;
	public int x,y;
	public int exp=0;
	/**this is a class for storing the expectation
	 * @param
	 * Expectation(state,x,y,exp)
	 * state - state
	 * x - position x
	 * y - position y
	 * exp - expectation */
	public Expectation(int state,int x,int y,int exp) 
	{
		this.state = state;
		this.x = x;
		this.y = y;
		this.exp = exp;
	}
}
