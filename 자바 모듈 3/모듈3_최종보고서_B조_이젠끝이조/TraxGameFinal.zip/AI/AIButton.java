package AI;

import java.util.ArrayList;
/*Button for AI*/
public class AIButton
{
	public int state = 0;
	public boolean click_en = false, click_ch = false;
	static AILineCheck check = new AILineCheck();

	//constructor
	public AIButton(int x, int y)
	{
		state = 0;
	}

	//check enable and bound
	public static Boolean check(int x, int y)
	{
		if(y+1<=AIFrame.n-1 && x+1<=AIFrame.n-1 && y-1>=0 && x-1>=0){
			int index=AIFrame.n*y+x;
			return AIFrame.btns[index].click_en;
		}
		else
			return false;
	}
	
	//return state
	public int getState()
	{
		return state;
	}
	
	/*return the around state(top,bottom,left,right)
	 *            top 
	 *
	 * left    this tile    right  
	 * 
	 *            bottom
	 * */
	public static int[] getAround(int x, int y)
	{
		int left=0, right=0, top=0, bottom=0;
		if(y-1>=0){
			top = AIFrame.btns[AIFrame.n*(y-1)+x].getState();
		}
		if(y+1<=AIFrame.n-1){
			bottom = AIFrame.btns[AIFrame.n*(y+1)+x].getState();
		}
		if(x-1>=0){
			left = AIFrame.btns[AIFrame.n*y+(x-1)].getState();
		}
		if(x+1<=AIFrame.n-1){
			right = AIFrame.btns[AIFrame.n*y+(x+1)].getState();
		}

		int result[]= {top,bottom,left,right};
		return result;
	}
	
	/* define the possible states
	 * top,bottom,left,right
	 *            top 
	 *
	 * 	left    this tile    right  
	 * 
	 *     	     bottom
	 * */
	public static ArrayList<Integer> AroundRoop(int x, int y)
	{	
		int AroundState[] = getAround(x,y);
		ArrayList<Integer> roop= new ArrayList<>();
		
		//No tile around this button.
		if(AroundState[0]==0 && AroundState[1]==0 && AroundState[2]==0 && AroundState[3]==0)
		{
			roop.add(3);
			roop.add(5);
			return roop;
		}
		//Initialize roop with every state
		for(int i=1;i<=6;i++){
			roop.add(i);
		}
		
		if(AroundState[0]==0);//No tile over this tile(top)
		else if(AroundState[0]==1||AroundState[0]==2||AroundState[0]==5)//If the state is 1/2/5(white linked)
			AroundState[0]=1;
		else//black linked
			AroundState[0]=2;
		
		switch(AroundState[0])
		{
		case 1 :{//white linked
			ArrayList<Integer> check= new ArrayList<>();
			check.add(1);
			check.add(2);
			check.add(6);
			roop.removeAll(check);
			break;
		}
		case 2 :{//black linked
			ArrayList<Integer> check= new ArrayList<>();
			check.add(3);
			check.add(4);
			check.add(5);
			roop.removeAll(check);
			break;
		}
		
		}
		
		if(AroundState[1]==0);//No tile at bottom
		else if(AroundState[1]==3||AroundState[1]==4||AroundState[1]==5)//The state at bottom is 3/4/5(white linked)
			AroundState[1]=1;
		else//black linked
			AroundState[1]=2;
				
		switch(AroundState[1])
		{
			
		case 1 :{//case of white linked
			ArrayList<Integer> check= new ArrayList<>();
			check.add(3);
			check.add(4);
			check.add(6);
			roop.removeAll(check);
			break;
		}
		case 2 :{//case of black linked
			ArrayList<Integer> check= new ArrayList<>();
			check.add(1);
			check.add(2);
			check.add(5);
			roop.removeAll(check);
			break;
		}
			
		}
		
		if(AroundState[2]==0);//No tile on left side of this tile
		else if(AroundState[2]==1||AroundState[2]==4||AroundState[2]==6)//If the state is 1/4/6(white linked)
			AroundState[2]=1;
		else//black linked
			AroundState[2]=2;
		switch(AroundState[2])
		{
		case 1 :{//white linked
			ArrayList<Integer> check= new ArrayList<>();
			check.add(1);
			check.add(4);
			check.add(5);
			roop.removeAll(check);
			break;
		}
		case 2 :{//black linked
			ArrayList<Integer> check= new ArrayList<>();
			check.add(2);
			check.add(3);
			check.add(6);
			roop.removeAll(check);
			break;
		}
		
		}

		if(AroundState[3]==0);//No tile on right side of this tile
		else if(AroundState[3]==2||AroundState[3]==3||AroundState[3]==6)//If the state is 2/3/6(white linked)
			AroundState[3]=1;
		else//black linked
			AroundState[3]=2;
		switch(AroundState[3])
		{
		case 1 :{//white linked
			ArrayList<Integer> check= new ArrayList<>();
			check.add(2);
			check.add(3);
			check.add(5);
			roop.removeAll(check);
			break;
		}
		case 2 :{//black linked
			ArrayList<Integer> check= new ArrayList<>();
			check.add(1);
			check.add(4);
			check.add(6);
			roop.removeAll(check);
			break;
		}
		
		}

		return roop;
	}
	
	//Auto finish
	public static void auto(int x, int y)
	{
		ArrayList<Integer> roop = AroundRoop(x,y);
		if(roop.size() == 1) {
			AIFrame.btns[AIFrame.n*y+x].state = roop.get(0);
			rightClick(x,y);
		} else if(roop.size() == 0){
			return;
		}
	}
	
	public static void rightClick(int x, int y)
	{
		//Do line check
		for(int i=1;i<=6;i++){
			if(AIFrame.btns[AIFrame.n*y+x].state == i){
				check.rightclick(x, y);
			}
		}
		
		if(AIFrame.btns[AIFrame.n*y+x].state != 0){//If there is tile.
			AIFrame.btns[AIFrame.n*y+x].click_ch = true;
			if(check(x,y+1)==false && y+1<=AIFrame.n-1){//If the bottom tile is in bound and click_en of bottom tile is false
				int x2=x;
				int y2=y+1;
				AIFrame.btns[AIFrame.n*y2+x2].click_en = true;//change clink_en to true.
			}
			if(check(x,y-1)==false && y-1>=0){//If the top tile is in bound and click_en of top tile is false.
				int x2=x;
				int y2=y-1;
				AIFrame.btns[AIFrame.n*y2+x2].click_en = true;//change clink_en to true.
			}
			if(check(x+1,y)==false && x+1<=AIFrame.n-1){//If the right tile is in bound and click_en of right tile is false.
				int x2=x+1;
				int y2=y;
				AIFrame.btns[AIFrame.n*y2+x2].click_en = true;//change clink_en to true.
			}
			if(check(x-1,y)==false && x-1>=0){//If the left tile is in bound and click_en of left tile is false.
				int x2=x-1;
				int y2=y;
				AIFrame.btns[AIFrame.n*y2+x2].click_en = true;//change clink_en to true.
			}
			//check bounds and state. Call the auto method(auto finish)
			if(y+1 <= AIFrame.n-1)
				if(AIFrame.btns[AIFrame.n*(y+1)+x].getState()==0)
					auto(x,y+1);
			if(y-1>=0)
				if(AIFrame.btns[AIFrame.n*(y-1)+x].getState()==0)
					auto(x,y-1);
			if(x+1<=AIFrame.n-1)
				if(AIFrame.btns[AIFrame.n*y+x+1].getState()==0)
					auto(x+1,y);
			if(x-1>=0)
				if(AIFrame.btns[AIFrame.n*y+x-1].getState()==0)
					auto(x-1,y);
		}
	}

}
