package Alg;

import java.util.ArrayList;

import GUI.trax_frame;
import GUI.win_frame;

public class VictoryLine extends line_check
{
	  public VictoryLine() {}
	  
	  public void victory_check(int index)
	  {
	      int lb = blackLine.size();
	      int lw = whiteLine.size();
	      
	      //Check black line
	      for(int i=0;i<lb;i++) {
	         int l = blackLine.get(i).size();
	         //no loop or size
	         if(l<3)
	            continue;
	         //loop, black win
	         if(count(blackLine,index) == 2) {
	            if(trax_frame.b_win == false) {
	            	trax_frame.b_win = true;
	            	new win_frame();
	            }
	            break;
	         }
	         //line, black win
	         if(line(blackLine.get(i).get(0), blackLine.get(i).get(l-1),1)) {
	            if(trax_frame.b_win == false) {
	            	trax_frame.b_win = true;
	            	new win_frame();
	            }
	            break;
	         }
	      }
	      //Check white line
	      for(int i=0;i<lw;i++) {
	         int l = whiteLine.get(i).size();
	         //no loop or line
	         if(l<3)
	            continue;
	         //loop, white win
	         if(count(whiteLine,index)==2) {
	        	if(trax_frame.w_win == false) {
	        		trax_frame.w_win = true;
	        		new win_frame();
	        	}
	            break;
	         }
	         //line, white win
	         if(line(whiteLine.get(i).get(0), whiteLine.get(i).get(l-1), 2)) {
	        	if(trax_frame.w_win == false) {
	        		trax_frame.w_win = true;
	        		new win_frame();
	        	}
	            break;
	         }
	      }
	  }

   	  //count how many items in it. If it has two item in one line that means loop
	  int count(ArrayList<ArrayList<Integer>> list, int item)
	  {
	      int cnt=0;
	      for(int i = 0; i < list.size(); i++){
	         for(int j = 0; j < list.get(i).size(); j++){
	            if(item == list.get(i).get(j)){
	               cnt++;
	            }
	         }
	      }
	      return cnt;
	   }
	   
	  
	  /*
	   * Check line-win condition
	   * color 1: black 2: white
	   * */
	   boolean line(int i1, int i2, int color)
	   {
	      int x1 = i1%n, x2 = i2%n, y1 = i1/n, y2 = i2/n;
	      int state1 = trax_frame.btns[i1].getState();
	      int state2 = trax_frame.btns[i2].getState();
	      int temp;
	      
	      //If width >= 8, change state each other.
	      if(getGap(x1,x2)>=8) {
	    	  //classify which is right state.
	         if(x1 < x2) {
	            temp = state1;
	            state1 = state2;
	            state2 = temp;
	         }
	         
	         switch(color) {
	         
	         case 1 :{//black
	            if(state2==2||state2==3||state2==6)
	               break;
	            else {
	               if(state1==1||state1==4||state1==6)
	                  break;
	               else
	                  return true;
	            }
	         }
	         case 2 :{//white
	            if(state2==1||state2==4||state2==5)
	               break;
	            else {
	               if(state1==2||state1==3||state1==5)
	                  break;
	               else
	                  return true;
	            }
	         }
	         }
	      }
	      
	      state1 = trax_frame.btns[i1].getState();
	      state2 = trax_frame.btns[i2].getState();
	      
	      if(getGap(y1,y2)>=8) {
	    	 //classify which is upper state.
	         if(y1<y2) {
	            temp = state1;
	            state1 = state2;
	            state2 = temp;
	         }
	         
	         switch(color) {
	         case 1 :{//black
	            if(state2==3||state2==4||state2==5)
	               break;
	            else {
	               if(state1==1||state1==2||state1==5)
	                  break;
	               else
	                  return true;
	            }
	         }
	         case 2 :{//white
	            if(state2==1||state2==2||state2==6)
	               break;
	            else {
	               if(state1==3||state1==4||state1==6)
	                  break;
	               else
	                  return true;
	            }
	         }
	         }
	         
	      }
	      return false;
	   }
}
