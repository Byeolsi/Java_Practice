package Alg;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.undo.*;

import GUI.trax_frame;


/*
 * It's for storing the line state, which is the index of connected tile
 * */
public class line_check
{
   public static ArrayList<ArrayList<Integer>> whiteLine = new ArrayList<ArrayList<Integer>>();
   public static ArrayList<ArrayList<Integer>> blackLine = new ArrayList<ArrayList<Integer>>();
   int n = trax_frame.n;
   public line_check() {}
   
   public void rightclick(int x, int y)
   {
	   
      boolean[] checkW= {false,false,false,false};
      boolean[] checkB= {false,false,false,false};
      int Orindex = n*y+x;
      int[] index = {-1,-1,-1,-1};//First index
      int[] indindex = {-1,-1,-1,-1};//Second index
      int[] connect = {y*n+(x+1),y*n+(x-1),(y-1)*n+x,(y+1)*n+x};//Index of around tiles.
      
      int lw = whiteLine.size();
      int lb = blackLine.size();
      
      VictoryLine victory = new VictoryLine();
      
      //Check if there is connected line.
      check(connect, checkW, checkB, index, indindex);
      
      whiteline(x,y,checkW,index);
      blackline(x,y,checkB,index);
      
      //If there is no connected line, add new line
      if(checkW[0] == false && checkW[1] == false && checkW[2] == false && checkW[3] == false) {
         ArrayList<Integer> line = new ArrayList<Integer>();
         line.add(n*y+x);
         whiteLine.add(line);
      }
      //If there is no connected line, add new line
      if(checkB[0] == false && checkB[1] == false && checkB[2] == false && checkB[3] == false) {
         ArrayList<Integer> line = new ArrayList<Integer>();
         line.add(n*y+x);
         blackLine.add(line);
      }
      
      lw = whiteLine.size();
      lb = blackLine.size();
      
      merge(Orindex);
      
      lw = whiteLine.size();
      lb = blackLine.size();
      
      victory.victory_check(Orindex);
   }
   
   //Store the white line state
   public void whiteline(int x, int y, boolean[] checkW, int[] index)
   {
      int Orindex=n*y+x;
      for(int dir=0; dir<4;dir++) {
    	 //If there is connected one.
         if(checkW[dir]) { 
            
            int l =whiteLine.get(index[dir]).size();
            int lastX=whiteLine.get(index[dir]).get(l-1)%n;
            int lastY=whiteLine.get(index[dir]).get(l-1)/n;
            //If loop, add last
            if((getGap(x,lastX) <= 1 && getGap(y,lastY) <= 1) &&
            		getGap(x,lastX) * getGap(y,lastY) != 1)
               whiteLine.get(index[dir]).add(Orindex);
            else//else add first, so that it's stored in connected order
               whiteLine.get(index[dir]).add(0,Orindex);
         }
      }
   }
   //Store the black line state.
   public void blackline(int x, int y, boolean[] checkB, int[] index)
   {
      int Orindex=n*y+x;
      
      for(int dir=0;dir<4;dir++) {
         if(checkB[dir]) {
        	 
            int l =blackLine.get(index[dir]).size();
            int lastX=blackLine.get(index[dir]).get(l-1)%n;
            int lastY=blackLine.get(index[dir]).get(l-1)/n;
            //If loop, add last
            if((getGap(x,lastX) <= 1 && getGap(y,lastY) <= 1) &&
            		getGap(x,lastX) * getGap(y,lastY) != 1)
               blackLine.get(index[dir]).add(Orindex);
            else//else add first, so that it's stored in connected order
               blackLine.get(index[dir]).add(0,Orindex);
         }  
      }
   }
   //check if there is connected line.
   public void check(int[] connect, boolean[] checkW, boolean[] checkB, int[] index, int[] indindex)
   {
      int lw = whiteLine.size();
      int lb = blackLine.size();
      //White.
      for(int i=0;i<lw;i++) {
         for(int j=0;j<4;j++) {
        	//If there is.
            if(whiteLine.get(i).contains(connect[j])) {
               int state = trax_frame.btns[connect[j]].getState();
               boolean c = false;
               //store the index by the state of around tile.
               switch(j) {
               case 0: if(state==2||state==3||state==6) {
                  c=true;
               }
               break;
               case 1: if(state==1||state==4||state==6) {
                  c=true;
               }
               break;
               case 2: if(state==1||state==2||state==5) {
                  c=true;
               }
               break;
               case 3: if(state==3||state==4||state==5) {
                  c=true;
               }
               break;
               }
               if(c) {
                  checkW[j] = true;
                  index[j] = i;
                  indindex[j] = whiteLine.get(i).indexOf(connect[j]);
               }
               
            }
         }
      }
      //Black. same as white.
      for(int i=0;i<lb;i++) {
         for(int j=0;j<4;j++) {
            if(blackLine.get(i).contains(connect[j])) {
               int state = trax_frame.btns[connect[j]].getState();
               boolean c = false;
               switch(j) {
               case 0: if(!(state==2||state==3||state==6)) {
                  c=true;
               }
               break;
               case 1: if(!(state==1||state==4||state==6)) {
                  c=true;
               }
               break;
               case 2: if(!(state==1||state==2||state==5)) {
                  c=true;
               }
               break;
               case 3: if(!(state==3||state==4||state==5)) {
                  c=true;
               }
               break;
               }
               if(c) {
                  checkB[j]=true;
                  index[j]=i;
                  indindex[j]=blackLine.get(i).indexOf(connect[j]);
               }
            }
         }
      }
   }
   //Merge if there is same line which is stored separately
   public void merge(int Orindex)
   {
      int lw = whiteLine.size();
      int lb = blackLine.size();
      int count = 0;
      int[] index= {-1,-1};
      
      for(int i=0;i<lw;i++) {
    	 //Count the number of connected index, and store that index.
         if(whiteLine.get(i).contains(Orindex)) {
            index[count] = i;
            count++;
         }
         //If the tile is connected but stored separately.
         if(count==2) {
        	
            int i1 = whiteLine.get(index[0]).indexOf(Orindex);
            int i2 = whiteLine.get(index[1]).indexOf(Orindex);
            //To merge index[1] + index[0] remove i1.
            if(i1 == 0) {
               whiteLine.get(index[0]).remove(i1);
               //If the common tile is first in index[1](== i2), reverse the index[1]
               if(i2 == 0)
                  Collections.reverse(whiteLine.get(index[1]));
            } else {
               //If i1 is not the first in index[0], reverse the index[0]
               whiteLine.get(index[0]).remove(i1);
               Collections.reverse(whiteLine.get(index[0]));
               
               if(whiteLine.get(index[1]).indexOf(Orindex) == 0)
                  Collections.reverse(whiteLine.get(index[1]));
               
            }
            
            whiteLine.get(index[1]).addAll(whiteLine.get(index[0]));
            whiteLine.remove(index[0]);
            break;
         }
      }
      
      count=0;
      
      //merge the black line.
      //same as white one.
      for(int i=0;i<lb;i++) {
         if(blackLine.get(i).contains(Orindex)) {
            index[count]=i;
            count++;
         }
         if(count==2) {
            int i1 = blackLine.get(index[0]).indexOf(Orindex);
            int i2 = blackLine.get(index[1]).indexOf(Orindex);
            if(i1==0) {
               blackLine.get(index[0]).remove(i1);
               if(i2==0)
                  Collections.reverse(blackLine.get(index[1]));
            }
            else {
               blackLine.get(index[0]).remove(i1);
               Collections.reverse(blackLine.get(index[0]));
               if(blackLine.get(index[1]).indexOf(Orindex)==0)
                  Collections.reverse(blackLine.get(index[1]));
            }
            blackLine.get(index[1]).addAll(blackLine.get(index[0]));
            blackLine.remove(index[0]);
            break;
         }
      }
      
   }
   //return the gap
   int getGap(int x, int y)
   {
      int gap = x - y;
      if(gap>=0) {
         return gap;
      } else
         return -gap;
   }
}