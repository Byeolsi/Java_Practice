package Main;

import GUI.start_frame;

public class MainClass
{
	public static void main(String[] args)
	{
		start_frame frame = new start_frame();
	}
}