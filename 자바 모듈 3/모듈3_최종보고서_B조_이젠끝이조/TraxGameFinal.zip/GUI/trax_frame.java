package GUI;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;

import AI.AIPlayer;
import Alg.line_check;
import GUI.tileButton;



public class trax_frame
{
   static JFrame frame = new JFrame();
   public static int n=128, usable=0;
   public static boolean f_click=true;
   public static boolean b_win=false;
   public static boolean w_win=false;
   
   // Label & textfield 
   private Label lx;
   private Label ly;
   private Label lti;
   static TextField tfx;//text field x
   static TextField tfy;//text field y
   static TextField tti;//text field state
   private static TextArea record;//record area
   private Button ok;
   public static JLabel turn = new JLabel("White turn");//Label turn(white/black)
   
   private final static String newline = "\n";
   
   //Panel & Scroll bar
   private JPanel Toppanel = new JPanel();//Top Panel
   private JPanel Leftpanel = new JPanel();//Left Panel
   private JPanel Bottompanel = new JPanel();//Bottom Panel
   private JPanel Rightpanel = new JPanel();//Right Panel
   private JPanel GDpanel = new JPanel();//Game panel
   private GridLayout gridlay = new GridLayout(n, n);
   private JScrollPane scrollpane = new JScrollPane(GDpanel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
         JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

   private final String[] btn_Title = { "Img/exit.png", "Img/new.png", "Img/load.png", "Img/save.png",
         "Img/option.png", "Img/players.png", "Img/undo.png", "Img/lock.png", "Img/resign.png", "Img/help.png",
         "Img/chat.png", "Img/record.png", "Img/clock.png"};//Button Image name(function button)

   private final String[] btn_Text = { "EXIT", "NEW GAME", "LOAD GAME", "SAVE GAME", "OPTIONS", "PLAYERS",
         "UNDO 1 TURN", "LOCK", "RESIGN", "HELP", "CHAT", "RECORD", "CLOCK", "NOTES", "LOBBY" };//Button name(function button)

   private JButton[] IconBtns = new JButton[btn_Title.length];//Button Icon array(function button)
   private JButton aiBtn = new JButton();//AI Button(Temporal no image)
   public static tileButton[] btns = new tileButton[n*n];//Tile Button
   AIPlayer aiPlayer = new AIPlayer();//new AI Player

   public trax_frame(){}
   public void CreatePanel()
   {
      //Create text field at north side
      lx = new Label("X��ǥ : ", Label.RIGHT);//x
      ly = new Label("Y��ǥ :", Label.RIGHT);//y
      lti = new Label("Ÿ�ϸ��: ", Label.RIGHT);//state
      tfx = new TextField(1);//x
      tfy = new TextField(1);//y
      tti= new TextField(1);//state

      ok = new Button("OK");
      
      //addActionListener
      tfx.addActionListener(new EventHandler());
      tfy.addActionListener(new EventHandler());
      tti.addActionListener(new EventHandler());
      ok.addActionListener(new EventHandler());

      Toppanel.setLayout(new BoxLayout(Toppanel, BoxLayout.X_AXIS));//Set layout
      Toppanel.setBackground(Color.WHITE);//Set background color
      frame.add(Toppanel, BorderLayout.NORTH);//Add panel
      //Add Label,TextField
      Toppanel.add(lx);
      Toppanel.add(tfx);
      Toppanel.add(ly);
      Toppanel.add(tfy);
      Toppanel.add(lti);
      Toppanel.add(tti);
      Toppanel.add(ok);
      
      Toppanel.setLayout(new BoxLayout(Toppanel, BoxLayout.Y_AXIS));
      Leftpanel.setLayout(new BoxLayout(Leftpanel, BoxLayout.Y_AXIS));//Set layout
      Leftpanel.setBackground(Color.WHITE);//Set background color
      frame.add(Leftpanel, BorderLayout.WEST);//Add panel
      
      Rightpanel.setLayout(new BoxLayout(Rightpanel, BoxLayout.Y_AXIS));//Set layout
      
      JPanel tile = new JPanel();
      tile.setSize(300,200);
      
      tile.add(lx);
      tile.add(tfx);
      tile.add(ly);
      tile.add(tfy);
      tile.add(lti);
      tile.add(tti);
      tile.add(ok);
      
      record = new TextArea();
      record.setSize(300,400);
      record.setEditable(false);//Player cannot edit 
      
      //Add tile, record
      Rightpanel.add(tile);
      Rightpanel.add(record);
      Rightpanel.setPreferredSize(new Dimension(300, 600));//Set panel size
      
      frame.add(Rightpanel, BorderLayout.EAST);//Add panel
      
      //Create function button
      for (int j = 0; j < btn_Title.length; j++){
         IconBtns[j] = new JButton(new ImageIcon(btn_Title[j]));
         IconBtns[j].setPreferredSize(new Dimension(25, 25));
         IconBtns[j].setToolTipText(btn_Text[j]);
         Leftpanel.add(IconBtns[j]);
      }
      //Add AI Button
      Leftpanel.add(aiBtn);
      aiBtn.setPreferredSize(new Dimension(25,25));      
      aiBtn.addActionListener(new ActionListener() {
    	  @Override
    	  public void actionPerformed(ActionEvent e) 
    	  {
    		  aiPlayer.doRightClick();//AI Player do the turn
    	  }
      });
      //Exit
      IconBtns[0].addActionListener(new ActionListener() { 
         @Override
         public void actionPerformed(ActionEvent e)
         {
            System.exit(0);
         }
      });
      //New Game
      IconBtns[1].addActionListener(new ActionListener() { 
         @Override
         public void actionPerformed(ActionEvent e)
         {
            NewGame();
         }
      });
      
      
      Bottompanel.setLayout(new BorderLayout());//Set layout
      Bottompanel.setBackground(Color.WHITE);//Set background color
      Bottompanel.add(new JLabel("      \t\t\t\t  " + "Trax" + "      \t\t\t\t  "), BorderLayout.WEST);//Add Label(text)
      Bottompanel.add(turn,BorderLayout.CENTER);//Add Label turn
      
      frame.add(Bottompanel, BorderLayout.PAGE_END);//Add panel
      
      GDpanel.setLayout(gridlay);//Set game panel's layout
      GDpanel.setBackground(Color.GREEN);//Set background color

      //Create tile button and add to game panel(GDpanel)
      for (int i = 0; i < n*n; i++){
         btns[i] = new tileButton(i%n, i/n);
         GDpanel.add(btns[i].boardBts);
      }
      //Add scrollPane
      frame.add(scrollpane);
   }
   
   public static void printCoordinates(int x, int y, int state, boolean isAI)
   {
	   char printState = 0;
	   String printTurn = "\0";
	   
	   //Set symbol by state
	   if (state == 1 || state == 3) {
		   printState = '/';
	   }
	   else if (state == 2 || state == 4) {
		   printState = '\\';
	   }
	   else if (state == 5 || state == 6) {
		   printState = '+';
	   }
	   
	   //Print current turn
	   if (isAI) {
		   printTurn = "Current turn : AI";
	   }
	   else {
		   printTurn = "Current turn : Player";
	   }
	   
	   //String x,y,state,voundary
	   String print_xCoordinate = "Current x : ";
	   String print_yCoordinate = "Current y : ";
	   String print_stateCoordinate = "Current state : ";
	   String print_boundaryLine = "==============================";
	   
	   //Append texts to record
	   record.append(printTurn + newline);
	   record.append(print_xCoordinate + x + newline);
	   record.append(print_yCoordinate + y + newline);
	   record.append(print_stateCoordinate + printState + newline);
	   record.append(print_boundaryLine + newline);
   }
   
   public void NewGame()
   {
      ImageIcon image= new ImageIcon("TileImg/0.png");
      //Set button state,image,enable,change to zero, false
      for(tileButton bt : btns) {
         bt.state = 0;
         bt.boardBts.setIcon(image);
         bt.click_en = false;
         bt.click_ch = false;
      }
      //Clear the line information
      line_check.blackLine.clear();
      line_check.whiteLine.clear();
      //Initialize usable, win info, first_click
      usable = 0;
      b_win = false;
      w_win = false;
      f_click = true;
   }
   
   class EventHandler implements ActionListener {

	      @Override
	      public void actionPerformed(ActionEvent e) {
	         // TODO Auto-generated method stub
	         char single = '\'';
	         String xpos =tfx.getText();
	         String ypos = tfy.getText();
	         String tileimg = tti.getText();
	         int xx = Integer.parseInt(xpos);
	         int yy = Integer.parseInt(ypos);
	         if(tileimg.equals("/")){
	            ArrayList<Integer> roop = tileButton.AroundRoop(xx,yy);
	            int size = roop.size();
	            int AroundState[]= tileButton.getAround(xx,yy);
	            if(roop.contains(1)) {
	               trax_frame.btns[trax_frame.n*yy+xx].state=1;
	               tileButton.rightClick(xx, yy);
	               trax_frame.printCoordinates(xx, yy, 1, false);
	            }
	            else if(roop.contains(3)){
	               trax_frame.btns[trax_frame.n*yy+xx].state=3;
	               tileButton.rightClick(xx, yy);
	               trax_frame.printCoordinates(xx, yy, 3, false);
	            }
	            else
	            {
	               new error_frame();
	            }
	         }
	         else if(tileimg.equals("\\")){
	            ArrayList<Integer> roop = tileButton.AroundRoop(xx,yy);
	            int size = roop.size();
	            int AroundState[]= tileButton.getAround(xx,yy);
	            if(roop.contains(2)) {
	               trax_frame.btns[trax_frame.n*yy+xx].state=2;
	               tileButton.rightClick(xx, yy);
	               trax_frame.printCoordinates(xx, yy, 2, false);
	            }
	            else if(roop.contains(4)){
	               trax_frame.btns[trax_frame.n*yy+xx].state=4;
	               tileButton.rightClick(xx, yy);
	               trax_frame.printCoordinates(xx, yy, 4, false);
	            }
	            else
	            {
	               new error_frame();
	            }
	         }
	         
	         else if(tileimg.equals("+")){
	            ArrayList<Integer> roop = tileButton.AroundRoop(xx,yy);
	            int size = roop.size();
	            int AroundState[]= tileButton.getAround(xx,yy);
	            if(roop.contains(5)) {
	               trax_frame.btns[trax_frame.n*yy+xx].state=5;
	               tileButton.rightClick(xx, yy);
	               trax_frame.printCoordinates(xx, yy, 5, false);
	            }
	            else if(roop.contains(6)){
	               trax_frame.btns[trax_frame.n*yy+xx].state=6;
	               tileButton.rightClick(xx, yy);
	               trax_frame.printCoordinates(xx, yy, 6, false);
	            }
	            else
	            {
	               new error_frame();
	            }
	        }
	    }
    }
}