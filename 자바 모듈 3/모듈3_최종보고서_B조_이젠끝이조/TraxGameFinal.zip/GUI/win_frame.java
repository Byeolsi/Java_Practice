package GUI;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import Alg.line_check;
/*
 * If there is Winner, show this frame
 * */
@SuppressWarnings("serial")
public class win_frame extends JFrame
{
	//Constructor
	public win_frame()
	{
		setTitle("Winner!");//Title
		Container contentPane = this.getContentPane();
		JPanel pane = new JPanel();
		JButton buttonNew = new JButton("New");//New Button
		JButton buttonClose = new JButton("Close");//Close Button
		JLabel label = new JLabel();//Show win message
		GridBagLayout bag = new GridBagLayout();//Layout
		GridBagConstraints bc = new GridBagConstraints();//Constraints
		
		setBounds(150 , 150 , 300 , 200);
		//Show winner
		if(trax_frame.b_win)
			label.setText("Black Win!!!");
		else
			label.setText("White Win!!!");
		
		pane.setLayout(bag);//Set layout
		bc.gridx=1;//location
		bc.gridy=0;
		bag.setConstraints(label, bc);//Constraints
		pane.add(label);//Add Label
		
		bc.gridx=0;//location
		bc.gridy=1;
		bag.setConstraints(buttonNew, bc);//Constraints
		pane.add(buttonNew);//Add New Button
		
		bc.gridx=2;//location
		bc.gridy=1;
		bag.setConstraints(buttonClose, bc);//Constraints
		pane.add(buttonClose);//Add Close Button
		contentPane.add(pane);
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//Set default close operation
		
		buttonNew.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				NewGame();
				dispose();
			}
		});
		
		buttonClose.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				trax_frame.frame.dispose();
				dispose();
			}
		});
		
		//Set frame to show at center
		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension di = tk.getScreenSize();//Screen size
		Dimension di1 = super.getSize();//Frame size
		int xx = (int)(di.getWidth() / 2 - di1.getWidth() / 2);
		int yy = (int)(di.getHeight() / 2 - di1.getHeight() / 2);
		setLocation(xx, yy);
	}
	
	public void NewGame()
	{
		ImageIcon image= new ImageIcon("TileImg/0.png");//Default tile image(green)
		//Initialize button information
		for(tileButton bt : trax_frame.btns) {
			bt.state=0;
			bt.boardBts.setIcon(image);
			bt.click_en=false;
			bt.click_ch=false;
		}
		//Initialize trax_frame information
		trax_frame.usable=0;
		trax_frame.b_win=false;
		trax_frame.w_win=false;
		trax_frame.f_click=true;
		
		//Clear the line info
		line_check.whiteLine.clear();
		line_check.blackLine.clear();
	}
}
