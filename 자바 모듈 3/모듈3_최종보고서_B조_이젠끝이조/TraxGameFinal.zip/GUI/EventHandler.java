package GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class EventHandler extends trax_frame implements ActionListener
{
	@Override
    public void actionPerformed(ActionEvent e)
    {
	   //Get x,y,state
       String xpos = tfx.getText();
       String ypos = tfy.getText();
       String tileimg = tti.getText();
       
       int xx = Integer.parseInt(xpos);
       int yy = Integer.parseInt(ypos);
       //X,Y to Integer
       if(tileimg.equals("/")){//If "/"
          ArrayList<Integer> roop = tileButton.AroundRoop(xx,yy);//Get possible state
          
          if(roop.contains(1)) {//If state 1 is possible
             trax_frame.btns[trax_frame.n*yy+xx].state = 1;//Set state
             tileButton.rightClick(xx, yy);//Right click
          }else if(roop.contains(3)){//If state 3 is possible
             trax_frame.btns[trax_frame.n*yy+xx].state = 3;//Set state
             tileButton.rightClick(xx, yy);//Right click
          }else{//Invalid input
             new error_frame();
          }
       }else if(tileimg.equals("\\")){//If "\"
          ArrayList<Integer> roop = tileButton.AroundRoop(xx,yy);
          
          if(roop.contains(2)) {//If state 2 is possible 
             trax_frame.btns[trax_frame.n*yy+xx].state=2;//Set state
             tileButton.rightClick(xx, yy);//Right click
          }else if(roop.contains(4)){//If state 4 is possible
             trax_frame.btns[trax_frame.n*yy+xx].state=4;//Set state
             tileButton.rightClick(xx, yy);//Right click
          }else{//Invalid input
             new error_frame();
          }
       }else if(tileimg.equals("+")){//If "+"
          ArrayList<Integer> roop = tileButton.AroundRoop(xx,yy);
          
          if(roop.contains(5)) {//If state 5 is possible
             trax_frame.btns[trax_frame.n*yy+xx].state=5;//Set state
             tileButton.rightClick(xx, yy);//Right click
          }else if(roop.contains(6)){//If state 6 is possible
             trax_frame.btns[trax_frame.n*yy+xx].state=6;//Set state
             tileButton.rightClick(xx, yy);//Right click
          }else{//Invalid input
             new error_frame();
          }
       }
    }
}
