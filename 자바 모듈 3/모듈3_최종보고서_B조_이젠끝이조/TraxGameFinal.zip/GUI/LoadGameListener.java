package GUI;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
/*
 * Load the Game
 * */
class LoadGameListener implements ActionListener
{
	@Override
	public void actionPerformed(ActionEvent e)
	{
		Toolkit toolkit = Toolkit.getDefaultToolkit();//Get Toolkit
		Image img = toolkit.getImage("Img/en.gif");//Get Image
		trax_frame gameframe1 = new trax_frame();
		Menu menu = new Menu();//New Menu
		gameframe1.frame.setTitle("Trax Game");//Set title
		gameframe1.frame.setSize(1300, 600);//Set frame size
		
		menu.CreateMenu();//Create menu
		gameframe1.CreatePanel();//Create panel
		
		Toolkit tk = Toolkit.getDefaultToolkit();//Get Toolkit
		Dimension di = tk.getScreenSize();//Get screen size
		Dimension di1 = gameframe1.frame.getSize();//get frame size
		int xx = (int)(di.getWidth() / 2 - di1.getWidth() / 2);
		int yy = (int)(di.getHeight() / 2 - di1.getHeight() / 2);//set center
		gameframe1.frame.setLocation(xx, yy);//Set frame location to center
		
		gameframe1.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		gameframe1.frame.setIconImage(img);//Set icon image
		gameframe1.frame.setVisible(true);
		start_frame.frame.dispose();//Dispose the start frame
	}
}