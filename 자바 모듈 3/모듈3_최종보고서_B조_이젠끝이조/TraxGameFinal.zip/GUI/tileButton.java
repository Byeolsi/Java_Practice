package GUI;

import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.ToolTipManager;

import Alg.line_check;

@SuppressWarnings("serial")
/*Button for player*/
public class tileButton extends JFrame
{
	public int state = 0;
	public Dimension dim3 = new Dimension(44, 44);
	public static ImageIcon image;
	public JButton boardBts;
	public boolean click_en = false, click_ch = false;
	private static line_check check = new line_check();
	public static boolean turn = true;//true : white    false : black
	
	//constructor
	public tileButton(int x, int y)
	{
		setLayout(null);
		int index = trax_frame.n*y+x;
		state = 0;
		image = new ImageIcon("TileImg/0.png");//set button image
		boardBts = new JButton(image);
		boardBts.setPreferredSize(dim3);//set button size
		boardBts.addMouseListener(new MouseAdapter(){//add mouse listener
			
			@Override
			public void mousePressed(MouseEvent e)
			{
				if(click_en || trax_frame.f_click){//enable = true or first click = true
					if(e.getButton()==MouseEvent.BUTTON1 && !click_ch){//Left button, click_change = false
						if(trax_frame.usable != 0 && trax_frame.usable != index){
							//If player pressed another button, set previous button state to zero
							image = new ImageIcon("TileImg/0.png");
							trax_frame.btns[trax_frame.usable].boardBts.setIcon(image);
							trax_frame.btns[trax_frame.usable].state=0;
							trax_frame.usable=0;
						}

						trax_frame.usable=index;
						
						if(state==0){//If no tile on this button
							int AroundState[]=getAround(x,y);//Get around sate(top, button, left, right)
							if(AroundState[0]==0 && AroundState[1]==0 && AroundState[2]==0 && AroundState[3]==0) {
								//If not tiles around this button
								state = 3;
							}else {//If there are tiles around this button
								ArrayList<Integer> roop = AroundRoop(x,y);//Get possible states
								state=roop.get(0);
							}
						}
						else{//If tile is pressed.
							ArrayList<Integer> roop = AroundRoop(x,y);
							int size = roop.size();
							int tmp = roop.indexOf(state);//Get tile's state index
							
							if(tmp==size-1)//If it's last
								tmp=-1;//Go to the first index of roop array
							state=roop.get(tmp+1);//Set next state.
						}
						//Set button image
						for(int i=1; i<=6;i++){
							if(state==i){
								image= new ImageIcon("TileImg/"+ i +"_tmp.png");
								boardBts.setIcon(image);
							}
						}
					}else if(e.getButton()==MouseEvent.BUTTON3){//Right button pressed
						
						if(turn)//Set turn(white turn or black turn)
							turn = false;
						else
							turn = true;
						//Show present turn
						if(turn) {
							trax_frame.turn.setText("White turn");
						}else {
							trax_frame.turn.setText("Black turn");
						}
						//Call rightClick
						rightClick(x,y);
						//Write record
						trax_frame.printCoordinates(x, y, state, false);
					}
				}
			}
		});
		boardBts.setToolTipText("x : "+x+" / y : "+y);//Set ToolTip text
	    ToolTipManager m = ToolTipManager.sharedInstance();
	    m.setInitialDelay(666);//print delay is 0.666 second
	    m.setDismissDelay(3000);//ToolTip continue for 3 second
	}
	
	//check enable and bound
	public static Boolean check(int x, int y)
	{
		if(y+1<=trax_frame.n-1 && x+1<=trax_frame.n-1 && y-1>=0 && x-1>=0){
			int index=trax_frame.n*y+x;
			return trax_frame.btns[index].click_en;
		}
		else
			return false;
	}
	
	//return state
	public int getState()
	{
		return state;
	}
	
	/*return the around state(top,bottom,left,right)
	 *            top 
	 *
	 * left    this tile    right  
	 * 
	 *           bottom
	 * */
	public static int[] getAround(int x, int y)
	{
		int left=0, right=0, top=0, bottom=0;
		if(y-1>=0){
			top = trax_frame.btns[trax_frame.n*(y-1)+x].getState();
		}
		if(y+1<=trax_frame.n-1){
			bottom = trax_frame.btns[trax_frame.n*(y+1)+x].getState();
		}
		if(x-1>=0){
			left = trax_frame.btns[trax_frame.n*y+(x-1)].getState();
		}
		if(x+1<=trax_frame.n-1){
			right = trax_frame.btns[trax_frame.n*y+(x+1)].getState();
		}

		int result[]= {top,bottom,left,right};
		return result;
	}
	
	/* define the possible states
	 * top,bottom,left,right
	 *            top 
	 *
	 * 	left    this tile    right  
	 * 
	 *     	     bottom
	 * */
	public static ArrayList<Integer> AroundRoop(int x, int y)
	{
		int AroundState[] = getAround(x,y);
		ArrayList<Integer> roop = new ArrayList<>();
		//No tile around this button.
		if(AroundState[0]==0 && AroundState[1]==0 && AroundState[2]==0 && AroundState[3]==0){
			roop.add(3);
			roop.add(5);
			return roop;
		}
		//Initialize roop with every state
		for(int i=1;i<=6;i++){
			roop.add(i);
		}
		
		if(AroundState[0]==0);//No tile over this tile(top)
		else if(AroundState[0]==1||AroundState[0]==2||AroundState[0]==5)//If the state is 1/2/5(white linked)
			AroundState[0]=1;
		else//black linked
			AroundState[0]=2;
		switch(AroundState[0])
		{
		case 1 :{//white linked
			ArrayList<Integer> check= new ArrayList<>();
			check.add(1);
			check.add(2);
			check.add(6);
			roop.removeAll(check);
			break;
		}
		case 2 :{//black linked
			ArrayList<Integer> check= new ArrayList<>();
			check.add(3);
			check.add(4);
			check.add(5);
			roop.removeAll(check);
			break;
		}
		
		}

		
		if(AroundState[1]==0);//No tile at bottom
		else if(AroundState[1]==3 || AroundState[1]==4 || AroundState[1]==5)//The state at bottom is 3/4/5(white linked)
			AroundState[1]=1;
		else//black linked
			AroundState[1]=2;
		
		switch(AroundState[1])
		{
		case 1 :{//case of white linked
			ArrayList<Integer> check= new ArrayList<>();
			check.add(3);
			check.add(4);
			check.add(6);
			roop.removeAll(check);
			break;
		}
		case 2 :{//case of black linked
			ArrayList<Integer> check= new ArrayList<>();
			check.add(1);
			check.add(2);
			check.add(5);
			roop.removeAll(check);
			break;
		}
		
		}

		if(AroundState[2]==0);//No tile on left side of this tile
		else if(AroundState[2]==1||AroundState[2]==4||AroundState[2]==6)//If the state is 1/4/6(white linked)
			AroundState[2]=1;
		else//black linked
			AroundState[2]=2;
		switch(AroundState[2])
		{
		case 1 :{//white linked
			ArrayList<Integer> check= new ArrayList<>();
			check.add(1);
			check.add(4);
			check.add(5);
			roop.removeAll(check);
			break;
		}
		case 2 :{//black linked
			ArrayList<Integer> check= new ArrayList<>();
			check.add(2);
			check.add(3);
			check.add(6);
			roop.removeAll(check);
			break;
		}
		
		}

		
		if(AroundState[3]==0);//No tile on right side of this tile
		else if(AroundState[3]==2||AroundState[3]==3||AroundState[3]==6)//If the state is 2/3/6(white linked)
			AroundState[3]=1;
		else//black linked
			AroundState[3]=2;
		switch(AroundState[3])
		{
		case 1 :{//white linked
			ArrayList<Integer> check= new ArrayList<>();
			check.add(2);
			check.add(3);
			check.add(5);
			roop.removeAll(check);
			break;
		}
		case 2 :{//black linked
			ArrayList<Integer> check= new ArrayList<>();
			check.add(1);
			check.add(4);
			check.add(6);
			roop.removeAll(check);
			break;
		}
		
		}

		return roop;
	}
	//Auto finish
	public static void auto(int x, int y)
	{
		ArrayList<Integer> roop = AroundRoop(x,y);
		if(roop.size()==1) {
			trax_frame.btns[trax_frame.n*y+x].state = roop.get(0);
			rightClick(x,y);
		} else if(roop.size()==0){
			new error_frame();
		}
	}
	public static void rightClick(int x, int y)
	{
		//Do line check, set tile image
		for(int i=1;i<=6;i++){
			if(trax_frame.btns[trax_frame.n*y+x].state == i){
				image= new ImageIcon("TileImg/"+ i +".png");
				trax_frame.btns[trax_frame.n*y+x].boardBts.setIcon(image);
				check.rightclick(x, y);
			}
		}
		if(trax_frame.btns[trax_frame.n*y+x].state != 0){//If there is tile.
			trax_frame.btns[trax_frame.n*y+x].click_ch=true;
			if(check(x,y+1)==false && y+1<=trax_frame.n-1){//If the bottom tile is in bound or click_en of bottom tile is false
				int x2=x;
				int y2=y+1;
				trax_frame.btns[trax_frame.n*y2+x2].click_en=true;//change clink_en to true
			}
			if(check(x,y-1)==false && y-1>=0){//If the top tile is in bound or click_en of top tile is false.
				int x2=x;
				int y2=y-1;
				trax_frame.btns[trax_frame.n*y2+x2].click_en=true;//change clink_en to true.
			}
			if(check(x+1,y)==false && x+1<=trax_frame.n-1){//If the right tile is in bound or click_en of right tile is false.
				int x2=x+1;
				int y2=y;
				trax_frame.btns[trax_frame.n*y2+x2].click_en=true;//change clink_en to true.
			}
			if(check(x-1,y)==false && x-1>=0){//If the left tile is in bound or click_en of left tile is false.
				int x2=x-1;
				int y2=y;
				trax_frame.btns[trax_frame.n*y2+x2].click_en=true;//change clink_en to true.
			}
			
			trax_frame.usable=0;//Set usable to zero
			//check bounds and state. Call the auto method(auto finish)
			if(trax_frame.f_click)
				trax_frame.f_click=false;
			
			if(y+1<=trax_frame.n-1)
				if(trax_frame.btns[trax_frame.n*(y+1)+x].getState()==0)
					auto(x,y+1);
			
			if(y-1>=0)
				if(trax_frame.btns[trax_frame.n*(y-1)+x].getState()==0)
					auto(x,y-1);
			
			if(x+1<=trax_frame.n-1)
				if(trax_frame.btns[trax_frame.n*y+x+1].getState()==0)
					auto(x+1,y);
			
			if(x-1>=0)
				if(trax_frame.btns[trax_frame.n*y+x-1].getState()==0)
					auto(x-1,y);
		}
	}
}