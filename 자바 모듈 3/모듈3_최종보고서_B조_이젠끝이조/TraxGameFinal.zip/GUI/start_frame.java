package GUI;

import java.awt.*;
import javax.swing.*;

public class start_frame
{
	static JFrame frame = new JFrame();
	JButton b_NewGame = new JButton("New Game");//Button new Game
	JButton b_LoadGame = new JButton("Load Game");//Button load Game
	JTextField t_PlayerName = new JTextField("Enter Player Name");//TextField player name
	Font f_font1 = new Font("?��?��고딕", Font.PLAIN, 30);//font
    ImageIcon icon = new ImageIcon("Img/Trax_Main.PNG");//Main Image
    Toolkit toolkit = Toolkit.getDefaultToolkit();
	Image img = toolkit.getImage("Img/en.gif");//Frame Icon image
       
	//Constructor
	public start_frame()
	{
		JImagePanel imgPanel = new JImagePanel(icon.getImage());
		
		frame.setSize(800, 650);//frame size
		frame.setTitle("Trax Game Start");//frame title
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setIconImage(img);//Icon image
		frame.setLayout(null);//layout
		
		imgPanel.setSize(800, 650);//Image panel size
		imgPanel.setLayout(null);//Image panel layout
		
		t_PlayerName.setSize(300, 50);//TextField size
		t_PlayerName.setFont(f_font1);//TextField font
		t_PlayerName.setLocation(240, 280);//TextField location
		t_PlayerName.setHorizontalAlignment(JTextField.CENTER);//Alignment

		//Set New Game Button
		b_NewGame.setSize(300, 70);
		b_NewGame.setLocation(240, 380);
		b_NewGame.addActionListener(new LoadGameListener());//Add Listener
		b_NewGame.setFont(f_font1);
		//Set Load Game Button
		b_LoadGame.setSize(300, 70);
		b_LoadGame.setLocation(240, 480);
		b_LoadGame.setFont(f_font1);

		frame.add(imgPanel);//Add Start Image
		//Add Button, TextField
		imgPanel.add(b_NewGame);
		imgPanel.add(b_LoadGame);
		imgPanel.add(t_PlayerName);
		
		frame.setVisible(true);
		//Set frame to show at center
		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension di = tk.getScreenSize();//Get ScreenSize
		Dimension di1 = frame.getSize();//Get frame Size
		int xx = (int)(di.getWidth() / 2 - di1.getWidth() / 2);
		int yy = (int)(di.getHeight() / 2 - di1.getHeight() / 2);
		frame.setLocation(xx, yy);
	}
}