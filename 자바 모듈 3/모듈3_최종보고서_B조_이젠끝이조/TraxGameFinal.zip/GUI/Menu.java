package GUI;

import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

/*
 * No Listener
 * Just for future use.
 * */
public class Menu
{
	private JMenuBar menuBar = new JMenuBar();
	
	private JMenu file_menu = new JMenu("File");
	private JMenu game_menu = new JMenu("Game");
	private JMenu network_menu = new JMenu("Network");
	private JMenu utility_menu = new JMenu("Utility");
	private JMenu help_menu = new JMenu("Help");

	// File
	private JMenuItem F_Credits = new JMenuItem("Credits");
	private JMenuItem F_Loadgame = new JMenuItem("Load Game    		  \t F2");
	private JMenuItem F_Savegame = new JMenuItem("Save Game    		  \t F3");
	private JMenuItem F_Autosave = new JMenuItem("Autosave");
	private JMenuItem F_Loadoption = new JMenuItem("Load options");
	private JMenuItem F_Saveoption = new JMenuItem("Save options");
	private JMenuItem F_Exit = new JMenuItem("Exit");
	// Game
	private JMenuItem G_Newgame = new JMenuItem("New Game     \t F5");
	private JMenuItem G_Undo = new JMenuItem("Undo 1 turn   	 \t F6");
	private JMenuItem G_Resign = new JMenuItem("Resign");
	private JMenuItem G_Gamevariant = new JMenuItem("Game variant");
	private JMenuItem G_Option = new JMenuItem("Options      \t F7");
	private JMenuItem G_Player = new JMenuItem("Players      \t F8");
	private JMenuItem G_Swap = new JMenuItem("Swap");

	// Network
	private JMenuItem N_Host = new JMenuItem("Host a game");
	private JMenuItem N_Join = new JMenuItem("Join a game");
	private JMenuItem N_Disconnect = new JMenuItem("Disconnect");

	// Utility
	private JMenuItem U_Help = new JMenuItem("Help \t Ctrl-H");
	private JMenuItem U_Chat = new JMenuItem("Chat");
	private JMenuItem U_Record = new JMenuItem("Record \t Ctrl-R");
	private JMenuItem U_Clock = new JMenuItem("Clock \t Ctrl-C");
	private JMenuItem U_Notes = new JMenuItem("Notes  \t Ctrl-N");
	private JMenuItem U_Lobby = new JMenuItem("Lobby");

	// Help
	private JMenuItem H_Index = new JMenuItem("Index");
	private JMenuItem H_License = new JMenuItem("License");
	private JMenuItem H_Howto = new JMenuItem("How to use help");
	private JMenuItem H_Plugins = new JMenuItem("Plugins");
	private JMenuItem H_Overview = new JMenuItem("Overview");
	private JMenuItem H_Rules = new JMenuItem("Rules");
	private JMenuItem H_Notation = new JMenuItem("Notation");
	private JMenuItem H_Strategy = new JMenuItem("Strategy");

	public void CreateMenu()
	{
		
		//Set menuBar
		menuBar.setBorder(BorderFactory.createLineBorder(Color.WHITE));
		menuBar.setBackground(Color.WHITE);

		//Add Menu to menuBar
		menuBar.add(new JLabel("      \t\t\t\t  "));
		menuBar.add(file_menu);
		menuBar.add(game_menu);
		menuBar.add(network_menu);
		menuBar.add(utility_menu);
		menuBar.add(help_menu);

		//Add MenuItem to Menu
		//File
		file_menu.add(F_Credits);
		file_menu.add(F_Loadgame);
		file_menu.add(F_Savegame);
		file_menu.add(F_Autosave);
		file_menu.add(F_Loadoption);
		file_menu.add(F_Saveoption);
		file_menu.addSeparator();
		file_menu.add(F_Exit);
		//Game
		game_menu.add(G_Newgame);
		game_menu.add(G_Undo);
		game_menu.add(G_Resign);
		game_menu.addSeparator();
		game_menu.add(G_Gamevariant);
		game_menu.add(G_Option);
		game_menu.add(G_Player);
		game_menu.add(G_Swap);
		
		//Network
		network_menu.add(N_Host);
		network_menu.add(N_Join);
		network_menu.add(N_Disconnect);

		//Utility
		utility_menu.add(U_Help);
		utility_menu.add(U_Chat);
		utility_menu.add(U_Record);
		utility_menu.add(U_Clock);
		utility_menu.add(U_Notes);
		utility_menu.add(U_Lobby);

		//Help
		help_menu.add(H_Index);
		help_menu.add(H_License);
		help_menu.add(H_Howto);
		help_menu.add(H_Plugins);
		help_menu.addSeparator();
		help_menu.add(H_Overview);
		help_menu.add(H_Rules);
		help_menu.add(H_Notation);
		help_menu.add(H_Strategy);

		//Add menuBar to frame
		trax_frame.frame.setJMenuBar(menuBar);

	}
}
