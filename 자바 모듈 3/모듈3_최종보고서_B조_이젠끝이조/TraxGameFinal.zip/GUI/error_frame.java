package GUI;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

/*
 * Tell player the error
 * */
@SuppressWarnings("serial")
public class error_frame extends JFrame
{
	public error_frame()
	{
		setTitle("error!");
		Container contentPane = this.getContentPane();
		JPanel pane = new JPanel();
		JButton buttonClose = new JButton("Close");//Close button
		JLabel label = new JLabel();
		GridBagLayout bag = new GridBagLayout();//Layout
		GridBagConstraints bc = new GridBagConstraints();//Constraints
		
		setBounds(150 , 150 , 300 , 200);//Frame bound
		
		label.setFont(new Font("Consolas",Font.ITALIC,30));//Set font, size
		label.setText("Error!!");//Set text
		pane.setLayout(bag);//Layout to GridBagLayout
		bc.gridx=0;//location
		bc.gridy=0;
		bag.setConstraints(label, bc);//Set constraints
		pane.add(label);//Add label
		
		bc.gridx=0;//location
		bc.gridy=1;
		bag.setConstraints(buttonClose, bc);//Set constraints
		pane.add(buttonClose);//Add button close
		contentPane.add(pane);//Add Pane
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//Set default close operation
		
		buttonClose.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();//Close this frame
			}
		});
		//Locate the frame at center
		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension di = tk.getScreenSize();
		Dimension di1 = super.getSize();
		int xx = (int)(di.getWidth() / 2 - di1.getWidth() / 2);
		int yy = (int)(di.getHeight() / 2 - di1.getHeight() / 2);
		setLocation(xx, yy);
	}
}
