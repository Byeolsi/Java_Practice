



import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;

@SuppressWarnings("serial")
public class Trax_frame extends JFrame implements ActionListener, KeyListener, MouseListener{

   /*****************************************************************************
    * 蹂??닔 ?꽑?뼵 ?븘?뱶
    ****************************************************************************/

   private int frameWidth = 1600;
   private int frameHeight = 800;

   /*****************************************************************************
    * 硫붾돱諛?
    ****************************************************************************/

   private JMenu file_menu = new JMenu("File"); // '?뙆?씪'?씠?씪?뒗 硫붾돱瑜? ?깮?꽦
   private JMenu game_menu = new JMenu("Game");
   private JMenu network_menu = new JMenu("Network");
   private JMenu utility_menu = new JMenu("Utility");
   private JMenu help_menu = new JMenu("Help");

   private JMenuBar menuBar = new JMenuBar(); // 硫붾돱諛붾?? ?깮?꽦

   // File
   private JMenuItem F_Credits = new JMenuItem("Credits");
   private JMenuItem F_Loadgame = new JMenuItem("Load Game            \t F2");
   private JMenuItem F_Savegame = new JMenuItem("Save Game            \t F3");
   private JMenuItem F_Autosave = new JMenuItem("Autosave");
   private JMenuItem F_Loadoption = new JMenuItem("Load options");
   private JMenuItem F_Saveoption = new JMenuItem("Save options");
   private JMenuItem F_Exit = new JMenuItem("Exit");

   // Game
   private JMenuItem G_Newgame = new JMenuItem("New Game     \t F5");
   private JMenuItem G_Undo = new JMenuItem("Undo 1 turn       \t F6");
   private JMenuItem G_Resign = new JMenuItem("Resign");
   private JMenuItem G_Gamevariant = new JMenuItem("Game variant");
   private JMenuItem G_Option = new JMenuItem("Options      \t F7");
   private JMenuItem G_Player = new JMenuItem("Players      \t F8");
   private JMenuItem G_Swap = new JMenuItem("Swap");

   // Network
   private JMenuItem N_Host = new JMenuItem("Host a game");
   private JMenuItem N_Join = new JMenuItem("Join a game");
   private JMenuItem N_Disconnect = new JMenuItem("Disconnect");

   // Utility
   private JMenuItem U_Help = new JMenuItem("Help \t Ctrl-H");
   private JMenuItem U_Chat = new JMenuItem("Chat");
   private JMenuItem U_Record = new JMenuItem("Record \t Ctrl-R");
   private JMenuItem U_Clock = new JMenuItem("Clock \t Ctrl-C");
   private JMenuItem U_Notes = new JMenuItem("Notes  \t Ctrl-N");
   private JMenuItem U_Lobby = new JMenuItem("Lobby");

   // Help
   private JMenuItem H_Index = new JMenuItem("Index");
   private JMenuItem H_License = new JMenuItem("License");
   private JMenuItem H_Howto = new JMenuItem("How to use help");
   private JMenuItem H_Plugins = new JMenuItem("Plugins");
   private JMenuItem H_Overview = new JMenuItem("Overview");
   private JMenuItem H_Rules = new JMenuItem("Rules");
   private JMenuItem H_Notation = new JMenuItem("Notation");
   private JMenuItem H_Strategy = new JMenuItem("Strategy");

   // Panel & Scroll bar
   private JPanel Leftpanel = new JPanel();
   private JPanel Bottompanel = new JPanel();
   private JPanel GDpanel = new JPanel();
   private JLabel stateLabel = new JLabel("상태표시줄");
   private GridLayout gridlay = new GridLayout(128, 128);
   private JScrollPane scrollpane = new JScrollPane(GDpanel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
         JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
   
   // Button & logic
   private JButton[] btns = new JButton[16384];
   private char[] logic = new char[16384];
   private char[] whattile = new char[16384];
   private int[] btncnt = new int[16384];
   private String b = "    Black to play";
   private String w = "    White to play";
   
   private String text;
   private int turncnt = 1;
   private int autoturncunt = 0;
   private boolean checkenter=true;
   private boolean checkfinal = false;
   private boolean user = false;
   
   //MaxLength & MaxWidth
   private int maxLength=0;
   private int maxWidth=0;
   private int demiLength=0;
   private int demiWidth=0;
   //Tile Icon
   private ImageIcon tile1 = new ImageIcon("Img/1_tmp.png");
   private ImageIcon tile2 = new ImageIcon("Img/2_tmp.png");
   private ImageIcon tile3 = new ImageIcon("Img/3_tmp.png");
   private ImageIcon tile4 = new ImageIcon("Img/4_tmp.png");
   private ImageIcon tile5 = new ImageIcon("Img/5_tmp.png");
   private ImageIcon tile6 = new ImageIcon("Img/6_tmp.png");
   private ImageIcon tile1_f = new ImageIcon("Img/1.png");
   private ImageIcon tile2_f = new ImageIcon("Img/2.png");
   private ImageIcon tile3_f = new ImageIcon("Img/3.png");
   private ImageIcon tile4_f = new ImageIcon("Img/4.png");
   private ImageIcon tile5_f = new ImageIcon("Img/5.png");
   private ImageIcon tile6_f = new ImageIcon("Img/6.png");

   /*****************************************************************************
    * ?깮?꽦?옄
    ****************************************************************************/

   public Trax_frame() {
      
      Toolkit toolkit = Toolkit.getDefaultToolkit();
      Image img = toolkit.getImage("Img/en.gif");

      // setLayout(null); // ?젅?씠?븘?썐?쓣 NULL濡? ?꽕?젙?븳?떎
      setTitle("Trax"); // Frame?쓽 ???씠?? ?씠由? 二쇨린
      setLocation(200, 200);
      setSize(frameWidth, frameHeight); // Frame?쓽 ?겕湲? ?꽕?젙
      // setResizable(false);

      CreateMenu(); // 硫붾돱諛붾?? 異붽??븳?떎.
      CreatePanel(); // ?뙣?꼸?쓣 異붽??븳?떎.
      Rectangle bounds = scrollpane.getViewport().getViewRect();
       Dimension size = scrollpane.getViewport().getViewSize();
      int x = (size.width - bounds.width) / 2;
       int y = (size.height - bounds.height) / 2;
       scrollpane.getViewport().setViewPosition(new Point(x, y));

      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Frame?쓽 X瑜? ?늻瑜쇨꼍?슦 醫낅즺
      setIconImage(img);
      setVisible(true); // ?깮?꽦?븳 Frame?쓣 ?쐢?룄?슦?뿉 肉뚮━湲?

   }

   /*****************************************************************************
    * 硫붾돱諛붾?? ?깮?꽦
    ****************************************************************************/
   private void CreateMenu() {

      // 硫붾돱諛? ?깋?긽 吏??젙
      menuBar.setBorder(BorderFactory.createLineBorder(Color.gray));
      menuBar.setBackground(Color.GRAY);

      // MenuBar - setting
      menuBar.add(new JLabel("      \t\t\t\t  "));
      menuBar.add(file_menu); // 硫붾돱諛붿뿉 '?뙆?씪'?씠?씪?뒗 硫붾돱瑜? 異붽?
      menuBar.add(game_menu);
      menuBar.add(network_menu);
      menuBar.add(utility_menu);
      menuBar.add(help_menu);

      file_menu.add(F_Credits);
      file_menu.add(F_Loadgame);
      file_menu.add(F_Savegame);
      file_menu.add(F_Autosave);
      file_menu.add(F_Loadoption);
      file_menu.add(F_Saveoption);
      file_menu.addSeparator(); // 援щ텇?꽑 湲뗪린
      file_menu.add(F_Exit); // '?뙆?씪' 硫붾돱 ?븞?뿉 '醫낅즺'?씪?뒗 硫붾돱?븘?씠?뀥 異붽?

      game_menu.add(G_Newgame);
      game_menu.add(G_Undo);
      game_menu.add(G_Resign);
      game_menu.addSeparator();
      game_menu.add(G_Gamevariant);
      game_menu.add(G_Option);
      game_menu.add(G_Player);
      game_menu.add(G_Swap);

      network_menu.add(N_Host);
      network_menu.add(N_Join);
      network_menu.add(N_Disconnect);

      utility_menu.add(U_Help);
      utility_menu.add(U_Chat);
      utility_menu.add(U_Record);
      utility_menu.add(U_Clock);
      utility_menu.add(U_Notes);
      utility_menu.add(U_Lobby);

      help_menu.add(H_Index);
      help_menu.add(H_License);
      help_menu.add(H_Howto);
      help_menu.add(H_Plugins);
      help_menu.addSeparator(); // 援щ텇?꽑 湲뗪린
      help_menu.add(H_Overview);
      help_menu.add(H_Rules);
      help_menu.add(H_Notation);
      help_menu.add(H_Strategy);

      TestListenr listener = new TestListenr(); // ?븘?옒?쓽 而댄룷?꼳?듃 由ъ뒪?꼫 ?겢?옒?뒪 ?깮?꽦
      F_Exit.addActionListener(listener); // '醫낅즺' 硫붾돱 ?븘?씠?뀥 ?꽑?깮?떆 諛쒖깮?븯?뒗 ?씠踰ㅽ듃 吏??젙
      setJMenuBar(menuBar);

   }

   /*****************************************************************************
    * ?뙣?꼸?쓣 留뚮뱺?떎. 
    ****************************************************************************/
   private void CreatePanel() {

      final String[] btn_Title = { "Img/exit.png", "Img/new.png", "Img/load.png", "Img/save.png", "Img/option.png",
            "Img/players.png", "Img/undo.png", "Img/lock.png", "Img/resign.png", "Img/help.png", "Img/chat.png",
            "Img/record.png", "Img/clock.png", "Img/notes.png", "Img/lobby.png" };
      Leftpanel.setLayout(new BoxLayout(Leftpanel, BoxLayout.Y_AXIS));
      Leftpanel.setBackground(Color.GRAY);
      add(Leftpanel, BorderLayout.WEST);
      JButton[] IconBtns = new JButton[15];
      for (int j = 0; j < btn_Title.length; j++) {

         IconBtns[j] = new JButton(new ImageIcon(btn_Title[j]));
         IconBtns[j].setPreferredSize(new Dimension(25, 25));
         Leftpanel.add(IconBtns[j]);

      }

      stateLabel.setBackground(Color.GRAY);
      stateLabel.setText("              Now Turn  :"+w+"    Tile Count  :  "+(turncnt-1)+"    Turn Count  : " + (turncnt - autoturncunt-1) + "     Max Length  :  " + maxLength + "        Max Width  :  "  + maxWidth);
      add(stateLabel, BorderLayout.SOUTH);

      GDpanel.setLayout(gridlay);
      GDpanel.setBackground(Color.GREEN);

      for (int i = 0; i < 16384; i++) {
         btns[i] = new JButton(new ImageIcon("Img/Pan_100_100.png"));
         btns[i].setActionCommand(String.valueOf(i));
         btns[i].setPreferredSize(new Dimension(100, 100));
         btns[i].addActionListener(this);
         logic[i] = 'X';
         whattile[i] = 'X';
         btncnt[i] = 0;
         GDpanel.add(btns[i]);
      }

      add(scrollpane);
      
   }

   /*****************************************************************************
    * TestListenr() ?겢?옒?뒪
    * 
    * 而댄룷?꼳?듃 ?씠踰ㅽ듃?뿉 ?뵲瑜? ?븸?뀡?쓣 ?젙?쓽
    * 
    ****************************************************************************/
   private class TestListenr implements ActionListener {

      public void actionPerformed(ActionEvent event) {
         if (event.getSource() == F_Exit) { // ?씠踰ㅽ듃媛? ExitItem?씠?씪硫?
            System.exit(1); // '醫낅즺' ?꽑?깮?떆 ?봽濡쒓렇?옩 醫낅즺
         } /*
             * else if(event.getSource() == SetItem) {
             * 
             * }
             */
      }
   }
   @Override
   public void actionPerformed(ActionEvent e) {
	  checkfinal = false;
      if (e.getSource() instanceof JButton) {
         if(checkenter==false && text!=e.getActionCommand()) {
            btns[Integer.parseInt(text)].setIcon(new ImageIcon("Img/Pan_100_100.png"));
            btncnt[Integer.parseInt(text)] = 0;
            whattile[Integer.parseInt(text)] = 'X';
            logic[Integer.parseInt(text)] = 'X';
         }
            text = e.getActionCommand();
            int x = Integer.parseInt(text);
            btns[x].addKeyListener(this);
            btns[x].addMouseListener(this);
            checkTile(x);
            drawTile(x, logic[x]);
            btncnt[x]++;
            checkenter=false;
        }
   }
   
   private void finaltile(int k) {
      turncnt++;
      btns[k].removeKeyListener(this);
      btns[k].setEnabled(false);
      if(whattile[k]=='A') btns[k].setDisabledIcon(resizeIcon(tile1_f, 100, 100));
      else if(whattile[k]=='B') btns[k].setDisabledIcon(resizeIcon(tile2_f, 100, 100));
      else if(whattile[k]=='C') btns[k].setDisabledIcon(resizeIcon(tile3_f, 100, 100));
      else if(whattile[k]=='D') btns[k].setDisabledIcon(resizeIcon(tile4_f, 100, 100));
      else if(whattile[k]=='E') btns[k].setDisabledIcon(resizeIcon(tile5_f, 100, 100));
      else if(whattile[k]=='F') btns[k].setDisabledIcon(resizeIcon(tile6_f, 100, 100));
      if(turncnt==2) {
         for (int i = 0; i < 16384; i++) {
            if(i==k) continue;
            btns[i].setEnabled(false);
            btns[i].setDisabledIcon(new ImageIcon("Img/Pan_100_100.png"));
         }
      }
      if(btncnt[k-128]==0) btns[k-128].setEnabled(true);
      if(btncnt[k+128]==0) btns[k+128].setEnabled(true);
      if(btncnt[k-1]==0) btns[k-1].setEnabled(true);
      if(btncnt[k+1]==0) btns[k+1].setEnabled(true);
      try {
    	  autotile();
      }
      catch(Exception e) {autoturncunt=0;}
      checkenter=true;
      if((turncnt-autoturncunt)%2==1)
      {
    	  user=true;
      }
      else if((turncnt-autoturncunt)%2==1)
      {
    	  user=false;
      }
      if(checkWinWhite_circle(k)) {
    	  JOptionPane.showMessageDialog(null, "Win White", "Win White", JOptionPane.PLAIN_MESSAGE);
    	  new_game();
      }
      else if(checkWinWhite_8tile(k)) {
    	  JOptionPane.showMessageDialog(null, "Win White", "Win White", JOptionPane.PLAIN_MESSAGE);
    	  new_game();
      }
      if (checkWinBlack_circle(k)) {
    	  JOptionPane.showMessageDialog(null, "Win Black", "Win Black", JOptionPane.PLAIN_MESSAGE);
    	  new_game();
      }
      else if(checkWinBlack_8tile(k)) {
    	  JOptionPane.showMessageDialog(null, "Win Black", "Win Black", JOptionPane.PLAIN_MESSAGE);
    	  new_game();
      }
      checkfinal = true;
   }
   
      
   private static Icon resizeIcon(ImageIcon icon, int resizedWidth, int resizedHeight) {
       Image img = icon.getImage();  
       Image resizedImage = img.getScaledInstance(resizedWidth, resizedHeight,  java.awt.Image.SCALE_SMOOTH);  
       return new ImageIcon(resizedImage);
   }
   
   private void drawTile(int i, char c) {
      if(logic[i]=='X') {
         switch (btncnt[i]%2) {
         case 0: 
            btns[i].setIcon(resizeIcon(tile5, 100, 100));
            whattile[i] = 'E';
            break;
         case 1: 
            btns[i].setIcon(resizeIcon(tile3, 100, 100));
            whattile[i] = 'C';
            break;
         case 2: 
            btns[i].setIcon(resizeIcon(tile1, 100, 100));
            whattile[i] = 'A';
            break;
         }
      }
      else if(logic[i]=='A') {   //위에가 하양
         switch (btncnt[i]%3) {
         case 0: 
            btns[i].setIcon(resizeIcon(tile3, 100, 100));
            whattile[i] = 'C';
            break;
         case 1: 
            btns[i].setIcon(resizeIcon(tile4, 100, 100));
            whattile[i] = 'D';
            break;
         case 2: 
            btns[i].setIcon(resizeIcon(tile5, 100, 100));
            whattile[i] = 'E';
            break;
         }
         
      }
      else if(logic[i]=='B') {   //위에가 검정
         switch (btncnt[i]%3) {
         case 0: 
            btns[i].setIcon(resizeIcon(tile1, 100, 100));
            whattile[i] = 'A';
            break;
         case 1: 
            btns[i].setIcon(resizeIcon(tile2, 100, 100));
            whattile[i] = 'B';
            break;
         case 2: 
            btns[i].setIcon(resizeIcon(tile6, 100, 100));
            whattile[i] = 'F';
            break;
         }
      }
      else if(logic[i]=='C') {   //오른 하양
         switch (btncnt[i]%3) {
         case 0: 
            btns[i].setIcon(resizeIcon(tile1, 100, 100));
            whattile[i] = 'A';
            break;
         case 1: 
            btns[i].setIcon(resizeIcon(tile4, 100, 100));
            whattile[i] = 'D';
            break;
         case 2: 
            btns[i].setIcon(resizeIcon(tile6, 100, 100));
            whattile[i] = 'F';
            break;
         }
      }
      else if(logic[i]=='D') {   //오른 검정
         switch (btncnt[i]%3) {
         case 0: 
            btns[i].setIcon(resizeIcon(tile2, 100, 100));
            whattile[i] = 'B';
            break;
         case 1: 
            btns[i].setIcon(resizeIcon(tile3, 100, 100));
            whattile[i] = 'C';
            break;
         case 2: 
            btns[i].setIcon(resizeIcon(tile5, 100, 100));
            whattile[i] = 'E';
            break;
         }
      }
      else if(logic[i]=='E') {   //아래 하양
         switch (btncnt[i]%3) {
         case 0: 
            btns[i].setIcon(resizeIcon(tile1, 100, 100));
            whattile[i] = 'A';
            break;
         case 1: 
            btns[i].setIcon(resizeIcon(tile2, 100, 100));
            whattile[i] = 'B';
            break;
         case 2: 
            btns[i].setIcon(resizeIcon(tile5, 100, 100));
            whattile[i] = 'E';
            break;
         }
      }
      else if(logic[i]=='F') {   //아래 검정
         switch (btncnt[i]%3) {
         case 0: 
            btns[i].setIcon(resizeIcon(tile3, 100, 100));
            whattile[i] = 'C';
            break;
         case 1: 
            btns[i].setIcon(resizeIcon(tile4, 100, 100));
            whattile[i] = 'D';
            break;
         case 2: 
            btns[i].setIcon(resizeIcon(tile6, 100, 100));
            whattile[i] = 'F';
            break;
         }
      }
      else if(logic[i]=='G') {   //왼 하양
         switch (btncnt[i]%3) {
         case 0: 
            btns[i].setIcon(resizeIcon(tile2, 100, 100));
            whattile[i] = 'B';
            break;
         case 1: 
            btns[i].setIcon(resizeIcon(tile3, 100, 100));
            whattile[i] = 'C';
            break;
         case 2: 
            btns[i].setIcon(resizeIcon(tile6, 100, 100));
            whattile[i] = 'F';
            break;
         }
      }
      else if(logic[i]=='H') {   //왼 검정
         switch (btncnt[i]%3) {
         case 0: 
            btns[i].setIcon(resizeIcon(tile1, 100, 100));
            whattile[i] = 'A';
            break;
         case 1: 
            btns[i].setIcon(resizeIcon(tile4, 100, 100));
            whattile[i] = 'D';
            break;
         case 2: 
            btns[i].setIcon(resizeIcon(tile5, 100, 100));
            whattile[i] = 'E';
            break;
         }
      }
      else if(logic[i]=='I') {   //위흰오른검
         switch (btncnt[i]%2) {
         case 0: 
            btns[i].setIcon(resizeIcon(tile3, 100, 100));
            whattile[i] = 'C';
            break;
         case 1: 
            btns[i].setIcon(resizeIcon(tile5, 100, 100));
            whattile[i] = 'E';
            break;
         }
      }
      else if(logic[i]=='J') {   //위검오른흰
         switch (btncnt[i]%2) {
         case 0: 
            btns[i].setIcon(resizeIcon(tile1, 100, 100));
            whattile[i] = 'A';
            break;
         case 1: 
            btns[i].setIcon(resizeIcon(tile6, 100, 100));
            whattile[i] = 'F';
            break;
         }
      }
      else if(logic[i]=='K') {   //위흰왼검
         switch (btncnt[i]%2) {
         case 0: 
            btns[i].setIcon(resizeIcon(tile4, 100, 100));
            whattile[i] = 'D';
            break;
         case 1: 
            btns[i].setIcon(resizeIcon(tile5, 100, 100));
            whattile[i] = 'E';
            break;
         }
      }
      else if(logic[i]=='L') {   //위검왼흰
         switch (btncnt[i]%2) {
         case 0: 
            btns[i].setIcon(resizeIcon(tile2, 100, 100));
            whattile[i] = 'B';
            break;
         case 1: 
            btns[i].setIcon(resizeIcon(tile6, 100, 100));
            whattile[i] = 'F';
            break;
         }
      }
      else if(logic[i]=='M') {   //밑흰오른검
         switch (btncnt[i]%2) {
         case 0: 
            btns[i].setIcon(resizeIcon(tile2, 100, 100));
            whattile[i] = 'B';
            break;
         case 1: 
            btns[i].setIcon(resizeIcon(tile5, 100, 100));
            whattile[i] = 'E';
            break;
         }
      }
      else if(logic[i]=='N') {   //밑검오른흰
         switch (btncnt[i]%2) {
         case 0: 
            btns[i].setIcon(resizeIcon(tile4, 100, 100));
            whattile[i] = 'D';
            break;
         case 1: 
            btns[i].setIcon(resizeIcon(tile6, 100, 100));
            whattile[i] = 'F';
            break;
         }
      }
      else if(logic[i]=='O') {   //밑흰왼검
         switch (btncnt[i]%2) {
         case 0: 
            btns[i].setIcon(resizeIcon(tile1, 100, 100));
            whattile[i] = 'A';
            break;
         case 1: 
            btns[i].setIcon(resizeIcon(tile5, 100, 100));
            whattile[i] = 'E';
            break;
         }
      }
      else if(logic[i]=='P') {   //밑검왼흰
         switch (btncnt[i]%2) {
         case 0: 
            btns[i].setIcon(resizeIcon(tile3, 100, 100));
            whattile[i] = 'C';
            break;
         case 1: 
            btns[i].setIcon(resizeIcon(tile6, 100, 100));
            whattile[i] = 'F';
            break;
         }
      }
      
   }
   
   private void checkTile(int i) {
      //타일 한개 인접 경우
      if((whattile[i-128]=='A' || whattile[i-128]=='B' || whattile[i-128]=='E') && whattile[i+128]=='X' && whattile[i-1]=='X' && whattile[i+1]=='X') {
         logic[i]='A';
      }
      else if((whattile[i-128]=='C' || whattile[i-128]=='D' || whattile[i-128]=='F') && whattile[i+128]=='X' && whattile[i-1]=='X' && whattile[i+1]=='X') {
         logic[i]='B';
      }
      else if(whattile[i-128]=='X' && whattile[i+128]=='X' && whattile[i-1]=='X' && (whattile[i+1]=='B' || whattile[i+1]=='C' || whattile[i+1]=='F')) {
         logic[i]='C';
      }
      else if(whattile[i-128]=='X' && whattile[i+128]=='X' && whattile[i-1]=='X' && (whattile[i+1]=='A' || whattile[i+1]=='D' || whattile[i+1]=='E')) {
         logic[i]='D';
      }
      else if(whattile[i-128]=='X' && (whattile[i+128]=='C' || whattile[i+128]=='D' || whattile[i+128]=='E') && whattile[i-1]=='X' && whattile[i+1]=='X') {
         logic[i]='E';
      }
      else if(whattile[i-128]=='X' && (whattile[i+128]=='A' || whattile[i+128]=='B' || whattile[i+128]=='F') && whattile[i-1]=='X' && whattile[i+1]=='X') {
         logic[i]='F';
      }
      else if(whattile[i-128]=='X' && whattile[i+128]=='X' && (whattile[i-1]=='A' || whattile[i-1]=='D' || whattile[i-1]=='F') && whattile[i+1]=='X') {
         logic[i]='G';
      }
      else if(whattile[i-128]=='X' && whattile[i+128]=='X' && (whattile[i-1]=='B' || whattile[i-1]=='C' || whattile[i-1]=='E') && whattile[i+1]=='X') {
         logic[i]='H';
      }
      
      //타일 두개 인접 경우
      else if((whattile[i-128]=='A' || whattile[i-128]=='B' || whattile[i-128]=='E') && whattile[i+128]=='X' && whattile[i-1]=='X' && (whattile[i+1]=='A' || whattile[i+1]=='D' || whattile[i+1]=='E')) {
         logic[i]='I';
      }
      else if((whattile[i-128]=='C' || whattile[i-128]=='D' || whattile[i-128]=='F') && whattile[i+128]=='X' && whattile[i-1]=='X' && (whattile[i+1]=='B' || whattile[i+1]=='C' || whattile[i+1]=='F')) {
         logic[i]='J';
      }
      else if((whattile[i-128]=='A' || whattile[i-128]=='B' || whattile[i-128]=='E') && whattile[i+128]=='X' && (whattile[i-1]=='B' || whattile[i-1]=='C' || whattile[i-1]=='E') && whattile[i+1]=='X') {
         logic[i]='K';
      }
      else if((whattile[i-128]=='C' || whattile[i-128]=='D' || whattile[i-128]=='F') && whattile[i+128]=='X' && (whattile[i-1]=='A' || whattile[i-1]=='D' || whattile[i-1]=='F') && whattile[i+1]=='X') {
         logic[i]='L';
      }
      else if(whattile[i-128]=='X' && (whattile[i+128]=='C' || whattile[i+128]=='D' || whattile[i+128]=='E') && whattile[i-1]=='X' && (whattile[i+1]=='A' || whattile[i+1]=='D' || whattile[i+1]=='E')) {
         logic[i]='M';
      }
      else if(whattile[i-128]=='X' && (whattile[i+128]=='A' || whattile[i+128]=='B' || whattile[i+128]=='F') && whattile[i-1]=='X' && (whattile[i+1]=='B' || whattile[i+1]=='C' || whattile[i+1]=='F')) {
         logic[i]='N';
      }
      else if(whattile[i-128]=='X' && (whattile[i+128]=='C' || whattile[i+128]=='D' || whattile[i+128]=='E') && (whattile[i-1]=='B' || whattile[i-1]=='C' || whattile[i-1]=='E') && whattile[i+1]=='X') {
         logic[i]='O';
      }
      else if(whattile[i-128]=='X' && (whattile[i+128]=='A' || whattile[i+128]=='B' || whattile[i+128]=='F') && (whattile[i-1]=='A' || whattile[i-1]=='D' || whattile[i-1]=='F') && whattile[i+1]=='X') {
         logic[i]='P';
      }
      
      
   }
   
   private void autotile() {
      for(int i=0;i<16384;i++) {
         if(btns[i].isEnabled()==false) continue;
         else {
            checkAutotile(i);      
         }
         
      }
      
   }
   
   private void checkAutotile(int i) {
      if((whattile[i-128]=='A' || whattile[i-128]=='B' || whattile[i-128]=='E') && (whattile[i+1]=='B' || whattile[i+1]=='C' || whattile[i+1]=='F')) {
         whattile[i] = 'D';
         btncnt[i]++;
         appear_text();
         finaltile(i);
         autoturncunt++;
      }
      else if((whattile[i-128]=='A' || whattile[i-128]=='B' || whattile[i-128]=='E') && (whattile[i-1]=='A' || whattile[i-1]=='D' || whattile[i-1]=='F')) {
         whattile[i] = 'C';
         btncnt[i]++;
         appear_text();
         finaltile(i);
         autoturncunt++;
      }
      else if((whattile[i+128]=='C' || whattile[i+128]=='D' || whattile[i+128]=='E') && (whattile[i+1]=='B' || whattile[i+1]=='C' || whattile[i+1]=='F')) {
         whattile[i] = 'A';
         btncnt[i]++;
         appear_text();
         finaltile(i);
         autoturncunt++;
      }
      else if((whattile[i+128]=='C' || whattile[i+128]=='D' || whattile[i+128]=='E') && (whattile[i-1]=='A' || whattile[i-1]=='D' || whattile[i-1]=='F')) {
         whattile[i] = 'B';
         btncnt[i]++;
         appear_text();
         finaltile(i);
         autoturncunt++;
      }
      else if((whattile[i-128]=='C' || whattile[i-128]=='D' || whattile[i-128]=='F') && (whattile[i+1]=='A' || whattile[i+1]=='D' || whattile[i+1]=='E')) {
         whattile[i] = 'B';
         btncnt[i]++;
         appear_text();
         finaltile(i);
         autoturncunt++;
      }
      else if((whattile[i-128]=='C' || whattile[i-128]=='D' || whattile[i-128]=='F') && (whattile[i-1]=='B' || whattile[i-1]=='C' || whattile[i-1]=='E')) {
         whattile[i] = 'A';
         btncnt[i]++;
         appear_text();
         finaltile(i);
         autoturncunt++;
      }
      else if((whattile[i+128]=='A' || whattile[i+128]=='B' || whattile[i+128]=='F') && (whattile[i+1]=='A' || whattile[i+1]=='D' || whattile[i+1]=='E')) {
         whattile[i] = 'C';
         btncnt[i]++;
         appear_text();
         finaltile(i);
         autoturncunt++;
      }
      else if((whattile[i+128]=='A' || whattile[i+128]=='B' || whattile[i+128]=='F') && (whattile[i-1]=='B' || whattile[i-1]=='C' || whattile[i-1]=='E')) {
         whattile[i] = 'D';
         btncnt[i]++;
         appear_text();
         finaltile(i);
         autoturncunt++;
      }
      else if((whattile[i-128]=='A' || whattile[i-128]=='B' || whattile[i-128]=='E') && (whattile[i+128]=='C' || whattile[i+128]=='D' || whattile[i+128]=='E')) {
         whattile[i] = 'E';
         btncnt[i]++;
         appear_text();
         finaltile(i);
         autoturncunt++;
      }
      else if((whattile[i+1]=='B' || whattile[i+1]=='C' || whattile[i+1]=='F') && (whattile[i-1]=='A' || whattile[i-1]=='D' || whattile[i-1]=='F')) {
         whattile[i] = 'F';
         btncnt[i]++;
         appear_text();
         finaltile(i);
         autoturncunt++;
      }
      else if((whattile[i-128]=='C' || whattile[i-128]=='D' || whattile[i-128]=='F') && (whattile[i+128]=='A' || whattile[i+128]=='B' || whattile[i+128]=='F')) {
         whattile[i] = 'F';
         btncnt[i]++;
         appear_text();
         finaltile(i);
         autoturncunt++;
      }
      else if((whattile[i+1]=='A' || whattile[i+1]=='D' || whattile[i+1]=='E') && (whattile[i-1]=='B' || whattile[i-1]=='C' || whattile[i-1]=='E')) {
         whattile[i] = 'E';
         btncnt[i]++;
         appear_text();
         finaltile(i);
         autoturncunt++;
      }
      
   }
   
   private boolean checkWinWhite_circle(int object_i) {
	   int i = 0, prev_i = 0;
	   
	   if (whattile[object_i] == 'A') {
		   if (!btns[object_i+128].isEnabled()) {
			   if (object_i+128 >= 16384) {
				   // Print Error!
				   return false;
			   }
			   i = object_i+128;
		   }
		   else if (!btns[object_i+1].isEnabled()) {
			   if (object_i+1 >= 16384) {
				   // Print Error!
				   return false;
			   }
			   i = object_i+1;
		   }
		   else {
			   return false;
		   }
	   }
	   
	   else if (whattile[object_i] == 'B') {
		   if (!btns[object_i+128].isEnabled()) {
			   if (object_i+128 >= 16384) {
				   // Print Error!
				   return false;
			   }
			   i = object_i+128;
		   }
		   else if (!btns[object_i-1].isEnabled()) {
			   if (object_i-1 < 0) {
				   // Print Error!
				   return false;
			   }
			   i = object_i-1;
		   }
		   else {
			   return false;
		   }
	   }
	   
	   else if (whattile[object_i] == 'C') {
		   if (!btns[object_i-128].isEnabled()) {
			   if (object_i-128 < 0) {
				   // Print Error!
				   return false;
			   }
			   i = object_i-128;
		   }
		   else if (!btns[object_i-1].isEnabled()) {
			   if (object_i-1 < 0) {
				   // Print Error!
				   return false;
			   }
			   i = object_i-1;
		   }
		   else {
			   return false;
		   }
	   }
	   
	   else if (whattile[object_i] == 'D') {
		   if (!btns[object_i-128].isEnabled()) {
			   if (object_i-128 < 0) {
				   // Print Error!
				   return false;
			   }
			   i = object_i-128;
		   }
		   else if (!btns[object_i+1].isEnabled()) {
			   if (object_i+1 >= 16384) {
				   // Print Error!
				   return false;
			   }
			   i = object_i+1;
		   }
		   else {
			   return false;
		   }
	   }
	   
	   else if (whattile[object_i] == 'E') {
		   if (!btns[object_i-128].isEnabled()) {
			   if (object_i-128 < 0) {
				   // Print Error!
				   return false;
			   }
			   i = object_i-128;
		   }
		   else if (!btns[object_i+128].isEnabled()) {
			   if (object_i+128 >= 16384) {
				   // Print Error!
				   return false;
			   }
			   i = object_i+128;
		   }
		   else {
			   return false;
		   }
	   }
	   
	   else if (whattile[object_i] == 'F') {
		   if (!btns[object_i-1].isEnabled()) {
			   if (object_i-1 < 0) {
				   // Print Error!
				   return false;
			   }
			   i = object_i-1;
		   }
		   else if (!btns[object_i+1].isEnabled()) {
			   if (object_i+1 >= 16384) {
				   // Print Error!
				   return false;
			   }
			   i = object_i+1;
		   }
		   else {
			   return false;
		   }
	   }
	   
	   else {
		   return false;
	   }
	   
	   prev_i = object_i;
	   while (object_i != i) {
		   if (whattile[i] == 'A') {
			   if (prev_i >= 16384 || prev_i < 0 || i >= 16384 || prev_i < 0) {
				   // Print Error!
				   return false;
			   }
			   if (prev_i == i+128) {
				   prev_i = i;
				   i = i+1;
			   }
			   else if (prev_i == i+1) {
				   prev_i = i;
				   i = i+128;
			   }
			   else {
				   return false;
			   }
		   }
		   
		   else if (whattile[i] == 'B') {
			   if (prev_i == i+128) {
				   prev_i = i;
				   i = i-1;
			   }
			   else if (prev_i == i-1) {
				   prev_i = i;
				   i = i+128;
			   }
			   else {
				   return false;
			   }
		   }
		   
		   else if (whattile[i] == 'C') {
			   if (prev_i == i-128) {
				   prev_i = i;
				   i = i-1;
			   }
			   else if (prev_i == i-1) {
				   prev_i = i;
				   i = i-128;
			   }
			   else {
				   return false;
			   }
		   }
		   
		   else if (whattile[i] == 'D') {
			   if (prev_i == i-128) {
				   prev_i = i;
				   i = i+1;
			   }
			   else if (prev_i == i+1) {
				   prev_i = i;
				   i = i-128;
			   }
			   else {
				   return false;
			   }
		   }
		   
		   else if (whattile[i] == 'E') {
			   if (prev_i == i-128) {
				   prev_i = i;
				   i = i+128;
			   }
			   else if (prev_i == i+128) {
				   prev_i = i;
				   i = i-128;
			   }
			   else {
				   return false;
			   }
		   }
		   
		   else if (whattile[i] == 'F') {
			   if (prev_i == i-1) {
				   prev_i = i;
				   i = i+1;
			   }
			   else if (prev_i == i+1) {
				   prev_i = i;
				   i = i-1;
			   }
			   else {
				   return false;
			   }
		   }
		   
		   else {
			   return false;
		   }
	   }
	   
	   return true;
   }
   
   private boolean checkWinBlack_circle(int object_i) {
	   int i = 0, prev_i = 0;
	   
	   if (whattile[object_i] == 'A') {
		   if (!btns[object_i-128].isEnabled()) {
			   if (object_i-128 >= 16384) {
				   // Print Error!
				   return false;
			   }
			   i = object_i-128;
		   }
		   else if (!btns[object_i-1].isEnabled()) {
			   if (object_i-1 >= 16384) {
				   // Print Error!
				   return false;
			   }
			   i = object_i-1;
		   }
		   else {
			   return false;
		   }
	   }
	   
	   else if (whattile[object_i] == 'B') {
		   if (!btns[object_i-128].isEnabled()) {
			   if (object_i-128 >= 16384) {
				   // Print Error!
				   return false;
			   }
			   i = object_i-128;
		   }
		   else if (!btns[object_i+1].isEnabled()) {
			   if (object_i+1 < 0) {
				   // Print Error!
				   return false;
			   }
			   i = object_i+1;
		   }
		   else {
			   return false;
		   }
	   }
	   
	   else if (whattile[object_i] == 'C') {
		   if (!btns[object_i+128].isEnabled()) {
			   if (object_i+128 < 0) {
				   // Print Error!
				   return false;
			   }
			   i = object_i+128;
		   }
		   else if (!btns[object_i+1].isEnabled()) {
			   if (object_i+1 < 0) {
				   // Print Error!
				   return false;
			   }
			   i = object_i+1;
		   }
		   else {
			   return false;
		   }
	   }
	   
	   else if (whattile[object_i] == 'D') {
		   if (!btns[object_i+128].isEnabled()) {
			   if (object_i+128 < 0) {
				   // Print Error!
				   return false;
			   }
			   i = object_i+128;
		   }
		   else if (!btns[object_i-1].isEnabled()) {
			   if (object_i-1 >= 16384) {
				   // Print Error!
				   return false;
			   }
			   i = object_i-1;
		   }
		   else {
			   return false;
		   }
	   }
	   
	   else if (whattile[object_i] == 'E') {
		   if (!btns[object_i-1].isEnabled()) {
			   if (object_i-1 < 0) {
				   // Print Error!
				   return false;
			   }
			   i = object_i-1;
		   }
		   else if (!btns[object_i+1].isEnabled()) {
			   if (object_i+1 >= 16384) {
				   // Print Error!
				   return false;
			   }
			   i = object_i+1;
		   }
		   else {
			   return false;
		   }
	   }
	   
	   else if (whattile[object_i] == 'F') {
		   if (!btns[object_i-128].isEnabled()) {
			   if (object_i-128 < 0) {
				   // Print Error!
				   return false;
			   }
			   i = object_i-128;
		   }
		   else if (!btns[object_i+128].isEnabled()) {
			   if (object_i+128 >= 16384) {
				   // Print Error!
				   return false;
			   }
			   i = object_i+128;
		   }
		   else {
			   return false;
		   }
	   }
	   
	   else {
		   return false;
	   }
	   
	   prev_i = object_i;
	   while (object_i != i) {
		   if (whattile[i] == 'A') {
			   if (prev_i >= 16384 || prev_i < 0 || i >= 16384 || prev_i < 0) {
				   // Print Error!
				   return false;
			   }
			   if (prev_i == i-128) {
				   prev_i = i;
				   i = i-1;
			   }
			   else if (prev_i == i-1) {
				   prev_i = i;
				   i = i-128;
			   }
			   else {
				   return false;
			   }
		   }
		   
		   else if (whattile[i] == 'B') {
			   if (prev_i == i-128) {
				   prev_i = i;
				   i = i+1;
			   }
			   else if (prev_i == i+1) {
				   prev_i = i;
				   i = i-128;
			   }
			   else {
				   return false;
			   }
		   }
		   
		   else if (whattile[i] == 'C') {
			   if (prev_i == i+128) {
				   prev_i = i;
				   i = i+1;
			   }
			   else if (prev_i == i+1) {
				   prev_i = i;
				   i = i+128;
			   }
			   else {
				   return false;
			   }
		   }
		   
		   else if (whattile[i] == 'D') {
			   if (prev_i == i+128) {
				   prev_i = i;
				   i = i-1;
			   }
			   else if (prev_i == i-1) {
				   prev_i = i;
				   i = i+128;
			   }
			   else {
				   return false;
			   }
		   }
		   
		   else if (whattile[i] == 'E') {
			   if (prev_i == i-1) {
				   prev_i = i;
				   i = i+1;
			   }
			   else if (prev_i == i+1) {
				   prev_i = i;
				   i = i-1;
			   }
			   else {
				   return false;
			   }
		   }
		   
		   else if (whattile[i] == 'F') {
			   if (prev_i == i-128) {
				   prev_i = i;
				   i = i+128;
			   }
			   else if (prev_i == i+128) {
				   prev_i = i;
				   i = i-128;
			   }
			   else {
				   return false;
			   }
		   }
		   
		   else {
			   return false;
		   }
	   }
	   
	   return true;
   }
   
   private int getX(int i) {
	   return i % 128;
   }
   
   private int getY(int i) {
	   return i / 128;
   }
   
   private int checkWinWhite_8tileEnd(int i, int prev_i) {
	   while (whattile[i] != 'X') {
		   if (whattile[i] == 'A') {
			   if (prev_i >= 16384 || prev_i < 0 || i >= 16384 || prev_i < 0) {
				   // Print Error!
			   }
			   if (prev_i == i+128) {
				   prev_i = i;
				   i = i+1;
			   }
			   else {
				   prev_i = i;
				   i = i+128;
			   }
		   }
		   
		   else if (whattile[i] == 'B') {
			   if (prev_i == i+128) {
				   prev_i = i;
				   i = i-1;
			   }
			   else {
				   prev_i = i;
				   i = i+128;
			   }
		   }
		   
		   else if (whattile[i] == 'C') {
			   if (prev_i == i-128) {
				   prev_i = i;
				   i = i-1;
			   }
			   else {
				   prev_i = i;
				   i = i-128;
			   }
		   }
		   
		   else if (whattile[i] == 'D') {
			   if (prev_i == i-128) {
				   prev_i = i;
				   i = i+1;
			   }
			   else {
				   prev_i = i;
				   i = i-128;
			   }
		   }
		   
		   else if (whattile[i] == 'E') {
			   if (prev_i == i-128) {
				   prev_i = i;
				   i = i+128;
			   }
			   else {
				   prev_i = i;
				   i = i-128;
			   }
		   }
		   
		   else if (whattile[i] == 'F') {
			   if (prev_i == i-1) {
				   prev_i = i;
				   i = i+1;
			   }
			   else {
				   prev_i = i;
				   i = i-1;
			   }
		   }
		   
		   else {
		   }
	   }
	   
	   return prev_i;
   }
   
   private int checkWinBlack_8tileEnd(int i, int prev_i) {
	   while (whattile[i] != 'X') {
		   if (whattile[i] == 'A') {
			   if (prev_i >= 16384 || prev_i < 0 || i >= 16384 || prev_i < 0) {
				   // Print Error!
			   }
			   if (prev_i == i-128) {
				   prev_i = i;
				   i = i-1;
			   }
			   else {
				   prev_i = i;
				   i = i-128;
			   }
		   }
		   
		   else if (whattile[i] == 'B') {
			   if (prev_i == i-128) {
				   prev_i = i;
				   i = i+1;
			   }
			   else {
				   prev_i = i;
				   i = i-128;
			   }
		   }
		   
		   else if (whattile[i] == 'C') {
			   if (prev_i == i+128) {
				   prev_i = i;
				   i = i+1;
			   }
			   else {
				   prev_i = i;
				   i = i+128;
			   }
		   }
		   
		   else if (whattile[i] == 'D') {
			   if (prev_i == i+128) {
				   prev_i = i;
				   i = i-1;
			   }
			   else {
				   prev_i = i;
				   i = i+128;
			   }
		   }
		   
		   else if (whattile[i] == 'E') {
			   if (prev_i == i-1) {
				   prev_i = i;
				   i = i+1;
			   }
			   else {
				   prev_i = i;
				   i = i-1;
			   }
		   }
		   
		   else if (whattile[i] == 'F') {
			   if (prev_i == i-128) {
				   prev_i = i;
				   i = i+128;
			   }
			   else {
				   prev_i = i;
				   i = i-128;
			   }
		   }
		   
		   else {
		   }
	   }
	   
	   return prev_i;
   }
   
   private boolean checkWinWhite_8tile(int object_i) {
	   int l = 0, r = 0, l_end = 0, r_end = 0, xDistance = 0, yDistance = 0;
	   
	   if (whattile[object_i] == 'A') {
		   l = object_i+128;
		   r = object_i+1;
	   }
	   else if (whattile[object_i] == 'B') {
		   l = object_i+128;
		   r = object_i-1;
	   }
	   else if (whattile[object_i] == 'C') {
		   l = object_i-128;
		   r = object_i-1;
	   }
	   else if (whattile[object_i] == 'D') {
		   l = object_i-128;
		   r = object_i+1;
	   }
	   else if (whattile[object_i] == 'E') {
		   l = object_i-128;
		   r = object_i+128;
	   }
	   else if (whattile[object_i] == 'F') {
		   l = object_i-1;
		   r = object_i+1;
	   }
	   else {
		   return false;
	   }
	   
	   l_end = checkWinWhite_8tileEnd(l, object_i);
	   r_end = checkWinWhite_8tileEnd(r, object_i);
	   xDistance = getX(r_end) - getX(l_end);
	   yDistance = getY(r_end) - getY(l_end);
	   
	   if (xDistance >= 7) {
		   if ((whattile[l_end] == 'B' || whattile[l_end] == 'C' || whattile[l_end] == 'F') && (whattile[r_end] == 'A' || whattile[r_end] == 'D' || whattile[r_end] == 'F')) {
			   return true;
		   }
	   }
	   else if (xDistance <= -7) {
		   if ((whattile[l_end] == 'A' || whattile[l_end] == 'D' || whattile[l_end] == 'F') && (whattile[r_end] == 'B' || whattile[r_end] == 'C' || whattile[r_end] == 'F')) {
			   return true;
		   }
	   }
	   if (yDistance >= 7) {
		   if ((whattile[l_end] == 'C' || whattile[l_end] == 'D' || whattile[l_end] == 'E') && (whattile[r_end] == 'A' || whattile[r_end] == 'B' || whattile[r_end] == 'E')) {
			   return true;
		   }
	   }
	   else if (yDistance <= -7) {
		   if ((whattile[l_end] == 'A' || whattile[l_end] == 'B' || whattile[l_end] == 'E') && (whattile[r_end] == 'C' || whattile[r_end] == 'D' || whattile[r_end] == 'E')) {
			   return true;
		   }
	   }
	   
	   return false;
   }
   
   private boolean checkWinBlack_8tile(int object_i) {
	   int l = 0, r = 0, l_end = 0, r_end = 0, xDistance = 0, yDistance = 0;
	   
	   if (whattile[object_i] == 'A') {
		   l = object_i-128;
		   r = object_i-1;
	   }
	   else if (whattile[object_i] == 'B') {
		   l = object_i-128;
		   r = object_i+1;
	   }
	   else if (whattile[object_i] == 'C') {
		   l = object_i+128;
		   r = object_i+1;
	   }
	   else if (whattile[object_i] == 'D') {
		   l = object_i+128;
		   r = object_i-1;
	   }
	   else if (whattile[object_i] == 'E') {
		   l = object_i-1;
		   r = object_i+1;
	   }
	   else if (whattile[object_i] == 'F') {
		   l = object_i-128;
		   r = object_i+128;
	   }
	   else {
		   return false;
	   }
	   
	   l_end = checkWinBlack_8tileEnd(l, object_i);
	   r_end = checkWinBlack_8tileEnd(r, object_i);
	   xDistance = getX(r_end) - getX(l_end);
	   yDistance = getY(r_end) - getY(l_end);
	   
	   if (xDistance >= 7) {
		   if ((whattile[l_end] == 'A' || whattile[l_end] == 'D' || whattile[l_end] == 'E') && (whattile[r_end] == 'B' || whattile[r_end] == 'C' || whattile[r_end] == 'E')) {
			   return true;
		   }
	   }
	   else if (xDistance <= -7) {
		   if ((whattile[l_end] == 'B' || whattile[l_end] == 'C' || whattile[l_end] == 'E') && (whattile[r_end] == 'A' || whattile[r_end] == 'D' || whattile[r_end] == 'E')) {
			   return true;
		   }
	   }
	   if (yDistance >= 7) {
		   if ((whattile[l_end] == 'A' || whattile[l_end] == 'B' || whattile[l_end] == 'F') && (whattile[r_end] == 'C' || whattile[r_end] == 'D' || whattile[r_end] == 'F')) {
			   return true;
		   }
	   }
	   else if (yDistance <= -7) {
		   if ((whattile[l_end] == 'C' || whattile[l_end] == 'D' || whattile[l_end] == 'F') && (whattile[r_end] == 'A' || whattile[r_end] == 'B' || whattile[r_end] == 'F')) {
			   return true;
		   }
	   }
	   
	   return false;
   }
   
   private void new_game() {
	   turncnt = 1;
	   checkfinal = false;
	   autoturncunt = 0;
	   for(int i=0;i<16384;i++) {
		   logic[i] = 'X';
		   whattile[i] = 'X';
		   btncnt[i] = 0;
		   btns[i].setEnabled(true);
		   btns[i].setIcon(new ImageIcon("Img/Pan_100_100.png"));
		   turncnt = 0;
	       autoturncunt = 0;
	       maxLength=0;
	       maxWidth=0;
	       demiLength=0;
	       demiWidth=0; 
	       checkfinal = false;
	   }
	   appear_text();
   }
   
   private void appear_text() {
	   max_count();
	   if((turncnt-autoturncunt)%2==1){
		   stateLabel.setText("             Now Turn  :"+w+"    Tile Count  :  "+(turncnt-1)+"    Turn Count  : " + (turncnt - autoturncunt-1) + "     Max Length  :  " + maxLength + "        Max Width  :  "  + maxWidth);
	   }
	   else{
		   stateLabel.setText("              Now Turn  :"+b+"    Tile Count  :  "+(turncnt-1)+"    Turn Count  : " + (turncnt - autoturncunt-1) + "     Max Length  :  " + maxLength + "        Max Width  :  "  + maxWidth);
	   }
	   
   };
   
   private void max_count() {
	   int num1;
	   int num2;
	   int num0;
	   
	   for(num0=0;num0<16384;num0++)
		{
			if(whattile[num0]!='X')
			{
				for(num1=0;num1<128;num1++)/*媛�濡쒓만�씠 痢≪젙*/
				{
					for(num2=0;num2<128;num2++)
					{
						if(whattile[num2+num1*128]!='X')
						{
							demiLength++;
							if(demiLength>maxLength) 
							{
								maxLength=demiLength;
						    }
									   
						}
						if(whattile[num2+num1*128]=='X'||num1==127)
						{
							demiLength=0;
					    }
					}
				}
			}
		}
	   for(num0=0;num0<16384;num0++)
		{
			if(whattile[num0]!='X')
			{
				for(num1=0;num1<128;num1++)/*�꽭濡쒓만�씠 痢≪젙*/
				{
					for(num2=0;num2<128;num2++)
					{
						if(whattile[num1+num2*128]!='X')
						{
							demiWidth++;
							if(demiWidth>maxWidth) 
							{
								maxWidth=demiWidth;
							}
									   
						}
						if(whattile[num1+num2*128]=='X'||num2==127)
						{
							demiWidth=0;
						}
					}
				}
			}
				   
		} 
   }
   
   @Override
   public void keyPressed(KeyEvent e) {
      if (e.getKeyCode()==KeyEvent.VK_ENTER){
        }
   }

   @Override
   public void keyReleased(KeyEvent e) {
      if (e.getKeyCode()==KeyEvent.VK_ENTER){
    	  if(checkfinal==false) finaltile(Integer.parseInt(text));
    	  stateLabel.setBackground(Color.GRAY);
    	  appear_text();
        }
   }
   
   @Override
   public void mouseClicked(MouseEvent e) {
      if(e.getButton()==3) {
         if(checkfinal==false) finaltile(Integer.parseInt(text));
         stateLabel.setBackground(Color.GRAY);
         appear_text();   
      }
      
   }

   @Override
   public void keyTyped(KeyEvent e) {
      // TODO Auto-generated method stub
      
   }
   
   @Override
   public void mouseEntered(MouseEvent e) {
      // TODO Auto-generated method stub
      
   }

   @Override
   public void mouseExited(MouseEvent e) {
      // TODO Auto-generated method stub
      
   }

   @Override
   public void mousePressed(MouseEvent e) {
      // TODO Auto-generated method stub
      
   }

   @Override
   public void mouseReleased(MouseEvent e) {
      // TODO Auto-generated method stub
      
   }


   
   
   /*****************************************************************************
    * 硫붿씤 硫붿냼?뱶
    ****************************************************************************/
   public static void main(String args[]) {

      new Trax_frame();

   }




}